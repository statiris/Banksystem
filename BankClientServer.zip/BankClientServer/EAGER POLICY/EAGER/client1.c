#include <stdio.h>   // Βιβλιοθήκη για είσοδο/έξοδο δεδομένων
#include <stdlib.h>  // Βιβλιοθήκη για λειτουργίες όπως dynamic memory allocation, rand() και exit()
#include <string.h>  // Βιβλιοθήκη για λειτουργίες συμβολοσειρών (string manipulation)
#include <time.h>    // Βιβλιοθήκη για τη χρήση της συνάρτησης time() για σπορά του rand()
#include <unistd.h>  // Βιβλιοθήκη για λειτουργίες συστήματος όπως close() και sleep()
#include <arpa/inet.h>  // Βιβλιοθήκη για λειτουργίες δικτύου όπως sockaddr_in και inet_pton()

#define TOTAL_QUERIES 300000  // Ορισμός του συνολικού αριθμού ερωτημάτων που θα δημιουργηθούν
#define QUERY_TYPE_1_PERCENT 0.35  // Ποσοστό τύπου ερώτησης 1 (35%)
#define QUERY_TYPE_2_PERCENT 0.35  // Ποσοστό τύπου ερώτησης 2 (35%)
#define QUERY_TYPE_3_PERCENT 0.25  // Ποσοστό τύπου ερώτησης 3 (25%)
#define QUERY_TYPE_4_PERCENT 0.05  // Ποσοστό τύπου ερώτησης 4 (5%)
#define SERVER_IP "127.0.0.1"  // IP διεύθυνση του server
#define SERVER_PORT 8080  // Πόρτα του server
#define BUFFER_SIZE 1024  // Μέγεθος του buffer για τη λήψη δεδομένων

#define DEPARTMENT_PROBABILITY 0.8  // 80% πιθανότητα οι Ερωτήσεις 1 και 2 να χρησιμοποιούν λογαριασμούς από το Τμήμα 1

// Συνάρτηση για τη δημιουργία τυχαίου αριθμού λογαριασμού από το Τμήμα 1 (1–500) ή το Τμήμα 2 (501–1000)
int get_random_account_from_department(int department) {
    if (department == 1) {
        return rand() % 500 + 1;  // Τμήμα 1: λογαριασμοί 1-500
    } else {
        return rand() % 500 + 501;  // Τμήμα 2: λογαριασμοί 501-1000
    }
}

// Συνάρτηση για τη δημιουργία τυχαίου αριθμού λογαριασμού χωρίς περιορισμό τμήματος
int get_random_account_any_department() {
    return rand() % 1000 + 1;  // Αριθμός λογαριασμού από 1 έως 1000, από οποιοδήποτε τμήμα
}

// Συνάρτηση για τη λήψη και εμφάνιση της απόκρισης του server (μόνο αν είναι επιτυχής)
void receive_response(int sock) {
    char buffer[BUFFER_SIZE];  // Buffer για τη λήψη δεδομένων
    ssize_t bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);  // Λήψη από τον server
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';  // Προσθήκη μηδενικού στο τέλος του ληφθέντος κειμένου
        printf("Server response: %s", buffer);  // Εκτύπωση της απόκρισης του server
    } else {
        printf("Failed to receive response from server.\n");  // Εμφάνιση μηνύματος αποτυχίας
    }
}

// Συνάρτηση για την εγγραφή της δημιουργημένης ερώτησης στο αρχείο workload
void log_query(FILE* workload_file, const char* query) {
    fprintf(workload_file, "%s", query);  // Εγγραφή της ερώτησης στο αρχείο workload
}

// Συνάρτηση για τη δημιουργία των λεπτομερειών ερώτησης και αποστολή τους στον Server 1
void generate_query(int sock, int query_type, FILE* workload_file) {
    char buffer[256];  // Buffer για την ερώτηση
    int accountNumberA;  // Αριθμός λογαριασμού A
    int accountNumberB;  // Αριθμός λογαριασμού B (για μεταφορές)
    float amount;  // Ποσό για συναλλαγές

    // Ερωτήσεις τύπου 1 και 2: 80% πιθανότητα να αφορούν λογαριασμούς από το Τμήμα 1, 20% από το Τμήμα 2
    if (query_type == 1 || query_type == 2) {
        if ((float)rand() / RAND_MAX < DEPARTMENT_PROBABILITY) {
            accountNumberA = get_random_account_from_department(1);  // 80% πιθανότητα για Τμήμα 1
        } else {
            accountNumberA = get_random_account_from_department(2);  // 20% πιθανότητα για Τμήμα 2
        }
    } else {
        accountNumberA = get_random_account_from_department(1);  // Για τον τύπο ερώτησης 4, μόνο το Τμήμα 1
    }

    switch (query_type) {
        case 1:  // Έλεγχος υπολοίπου του accountNumberA
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d, Account: %d\n", query_type, accountNumberA);
            break;

        case 2:  // Προσθήκη/Αφαίρεση χρημάτων από τον accountNumberA
            amount = (rand() % 2001) - 1000;  // Τυχαίο ποσό μεταξύ -1000 και +1000
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d, Account: %d, Amount: %.2f\n", query_type, accountNumberA, amount);
            break;

        case 3:  // Μεταφορά χρημάτων από τον accountNumberA στον accountNumberB (χωρίς περιορισμούς τμήματος)
            accountNumberA = get_random_account_any_department();  // Τυχαίος λογαριασμός από οποιοδήποτε τμήμα
            accountNumberB = get_random_account_any_department();  // Τυχαίος λογαριασμός από οποιοδήποτε τμήμα
            while (accountNumberB == accountNumberA) {
                accountNumberB = get_random_account_any_department();  // Βεβαιώσου ότι οι λογαριασμοί είναι διαφορετικοί
            }
            amount = (rand() % 1000) + 1;  // Τυχαίο ποσό μεταξύ 1 και 1000
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d, Account A: %d, Account B: %d, Amount: %.2f\n", query_type, accountNumberA, accountNumberB, amount);
            break;

        case 4:  // Εμφάνιση μέσου υπολοίπου του τμήματος (πάντα για το Τμήμα 1)
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d\n", query_type);
            break;
    }

    // Καταγραφή της ερώτησης στο αρχείο workload
    log_query(workload_file, buffer);

    // Αποστολή της δημιουργημένης ερώτησης στον server
    send(sock, buffer, strlen(buffer), 0);

    // Λήψη της απόκρισης από τον server
    receive_response(sock);
}

// Συνάρτηση για τη δημιουργία του workload για το Τμήμα 1 και την αποστολή του στον Server 1
void generate_workload(int department) {
    srand(time(NULL));  // Σπορά του γεννήτορα τυχαίων αριθμών

    // Δημιουργία socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);  // Δημιουργία socket για TCP σύνδεση
    if (sock < 0) {
        perror("Socket creation error");  // Μήνυμα σφάλματος αν αποτύχει η δημιουργία socket
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_addr;  // Δομή για τη διεύθυνση του server
    server_addr.sin_family = AF_INET;  // Οικογένεια διευθύνσεων: IPv4
    server_addr.sin_port = htons(SERVER_PORT);  // Μετατροπή της πόρτας στη σωστή μορφή

    // Μετατροπή της διεύθυνσης IPv4 από κείμενο σε δυαδική μορφή
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        perror("Invalid address/Address not supported");  // Σφάλμα αν η διεύθυνση δεν είναι έγκυρη ή δεν υποστηρίζεται
        close(sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);
    }

    // Σύνδεση με τον server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");  // Σφάλμα αν αποτύχει η σύνδεση
        close(sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);
    }

    // Άνοιγμα του αρχείου workload για εγγραφή
    FILE* workload_file = fopen("workload1.txt", "w");  // Άνοιγμα αρχείου για αποθήκευση των queries
    if (workload_file == NULL) {
        perror("Failed to open workload file");  // Σφάλμα αν αποτύχει το άνοιγμα του αρχείου
        close(sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < TOTAL_QUERIES; ++i) {
        float rand_value = (float)rand() / RAND_MAX;  // Δημιουργία τυχαίου αριθμού μεταξύ 0 και 1
        int query_type;

        // Ανάθεση τύπου ερώτησης με βάση τις πιθανότητες
        if (rand_value < QUERY_TYPE_1_PERCENT) {
            query_type = 1;  // Ερώτηση Τύπου 1 (35%)
        } else if (rand_value < QUERY_TYPE_1_PERCENT + QUERY_TYPE_2_PERCENT) {
            query_type = 2;  // Ερώτηση Τύπου 2 (35%)
        } else if (rand_value < QUERY_TYPE_1_PERCENT + QUERY_TYPE_2_PERCENT + QUERY_TYPE_3_PERCENT) {
            query_type = 3;  // Ερώτηση Τύπου 3 (25%)
        } else {
            query_type = 4;  // Ερώτηση Τύπου 4 (5%)
        }

        // Δημιουργία της ερώτησης και αποστολή της στον server
        generate_query(sock, query_type, workload_file);
    }

    // Κλείσιμο του αρχείου workload μετά την καταγραφή όλων των ερωτημάτων
    fclose(workload_file);

    close(sock);  // Κλείσιμο του socket
    printf("Workload for Department %d sent to Server 1 and saved to 'workload1.txt'.\n", department);  // Εκτύπωση μηνύματος επιβεβαίωσης
}

int main() {
    // Ο Client 1 δημιουργεί workload για το Τμήμα 1 και το στέλνει στον Server 1
    generate_workload(1);
    return 0;
}

