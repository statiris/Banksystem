#include <stdio.h>   // Εισαγωγή της βιβλιοθήκης για είσοδο/έξοδο
#include <stdlib.h>  // Εισαγωγή της βιβλιοθήκης για δυναμική μνήμη και άλλες συναρτήσεις όπως η exit()
#include <time.h>    // Εισαγωγή της βιβλιοθήκης για να χρησιμοποιήσουμε το time() για την σπορά του rand()

#define CENTRAL_ACCOUNT_FILE "accounts.txt"   // Ορισμός του ονόματος του αρχείου για τον κεντρικό λογαριασμό
#define DEP1_ACCOUNT_FILE "dep1_accounts.txt" // Ορισμός του ονόματος του αρχείου για τον λογαριασμό του τμήματος 1
#define DEP2_ACCOUNT_FILE "dep2_accounts.txt" // Ορισμός του ονόματος του αρχείου για τον λογαριασμό του τμήματος 2
#define MAX_ACCOUNTS 1000  // Ορισμός του μέγιστου αριθμού λογαριασμών σε 1000

// Συνάρτηση για την δημιουργία τυχαίου υπολοίπου μεταξύ 100 και 10000
float generate_random_balance() {
    return (float)(rand() % 10000 + 100);  // Επιστρέφει έναν τυχαίο αριθμό μεταξύ 100 και 10000
}

// Συνάρτηση για την αρχικοποίηση του κεντρικού αρχείου λογαριασμών με τυχαία υπόλοιπα
void initialize_central_accounts() {
    FILE *central_file = fopen(CENTRAL_ACCOUNT_FILE, "w");  // Άνοιγμα του αρχείου σε λειτουργία εγγραφής
    if (!central_file) {
        perror("Failed to open central account file for writing");  // Εμφάνιση σφάλματος αν αποτύχει το άνοιγμα
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με κωδικό αποτυχίας
    }

    srand(time(NULL));  // Σπορά της συνάρτησης rand() με την τρέχουσα ώρα

    // Δημιουργία 1000 λογαριασμών με τυχαία υπόλοιπα
    for (int account_number = 1; account_number <= MAX_ACCOUNTS; account_number++) {
        float balance = generate_random_balance();  // Δημιουργία τυχαίου υπολοίπου
        int department = (account_number <= 500) ? 1 : 2;  // Ανάθεση του τμήματος: 1 για λογαριασμούς 1-500, 2 για 501-1000
        fprintf(central_file, "%d,%d,%.2f\n", account_number, department, balance);  // Εγγραφή του λογαριασμού στο αρχείο
    }

    fclose(central_file);  // Κλείσιμο του αρχείου μετά την εγγραφή
}

// Συνάρτηση για την αρχικοποίηση των τοπικών αρχείων λογαριασμών από το κεντρικό αρχείο
void initialize_local_accounts() {
    FILE *central_file = fopen(CENTRAL_ACCOUNT_FILE, "r");  // Άνοιγμα του κεντρικού αρχείου σε λειτουργία ανάγνωσης
    if (!central_file) {
        perror("Failed to open central account file");  // Εμφάνιση σφάλματος αν αποτύχει το άνοιγμα
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με κωδικό αποτυχίας
    }

    FILE *dep1_file = fopen(DEP1_ACCOUNT_FILE, "w");  // Άνοιγμα του αρχείου για το τμήμα 1 σε λειτουργία εγγραφής
    FILE *dep2_file = fopen(DEP2_ACCOUNT_FILE, "w");  // Άνοιγμα του αρχείου για το τμήμα 2 σε λειτουργία εγγραφής
    if (!dep1_file || !dep2_file) {
        perror("Failed to open local account files for writing");  // Εμφάνιση σφάλματος αν αποτύχει το άνοιγμα οποιουδήποτε τοπικού αρχείου
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με κωδικό αποτυχίας
    }

    int account_number, department;
    float balance;
    char buffer[256];  // Buffer για την αποθήκευση γραμμών από το κεντρικό αρχείο

    // Διανομή λογαριασμών στα αρχεία dep1 και dep2 με βάση το τμήμα
    while (fgets(buffer, sizeof(buffer), central_file)) {  // Διαβάζει κάθε γραμμή από το κεντρικό αρχείο
        sscanf(buffer, "%d,%d,%f", &account_number, &department, &balance);  // Ανάλυση της γραμμής σε account_number, department και balance
        if (department == 1) {
            fprintf(dep1_file, "%d,%.2f\n", account_number, balance);  // Εγγραφή στον λογαριασμό του τμήματος 1
        } else {
            fprintf(dep2_file, "%d,%.2f\n", account_number, balance);  // Εγγραφή στον λογαριασμό του τμήματος 2
        }
    }

    fclose(central_file);  // Κλείσιμο του κεντρικού αρχείου
    fclose(dep1_file);     // Κλείσιμο του αρχείου του τμήματος 1
    fclose(dep2_file);     // Κλείσιμο του αρχείου του τμήματος 2
}

int main() {
    // Αρχικοποίηση του κεντρικού αρχείου λογαριασμών με τυχαία υπόλοιπα
    initialize_central_accounts();

    // Αρχικοποίηση των τοπικών αρχείων λογαριασμών από τα δεδομένα του κεντρικού αρχείου
    initialize_local_accounts();

    printf("Central and local account files have been initialized with random balances.\n");  // Εκτύπωση επιβεβαίωσης

    return 0;  // Επιστροφή κωδικού επιτυχίας
}

