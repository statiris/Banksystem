#include <stdio.h>  // Εισαγωγή βιβλιοθήκης για είσοδο/έξοδο
#include <stdlib.h> // Εισαγωγή βιβλιοθήκης για διαχείριση μνήμης και άλλες συναρτήσεις όπως η exit()
#include <string.h> // Εισαγωγή βιβλιοθήκης για χειρισμό συμβολοσειρών
#include <unistd.h> // Εισαγωγή βιβλιοθήκης για διάφορες λειτουργίες συστήματος (π.χ. close())
#include <arpa/inet.h> // Εισαγωγή βιβλιοθήκης για χειρισμό διευθύνσεων IP και δικτυακών λειτουργιών
#include <pthread.h>  // Εισαγωγή βιβλιοθήκης για πολυνηματικές διεργασίες (threads)

#define CENTRAL_PORT 8081 // Ορισμός της θύρας για τον κεντρικό server
#define BUFFER_SIZE 1024  // Ορισμός του μεγέθους του buffer για τα δεδομένα που μεταφέρονται
#define MAX_ACCOUNTS 1000 // Μέγιστος αριθμός λογαριασμών που μπορεί να διαχειριστεί ο server

// Δομή για την αποθήκευση δεδομένων λογαριασμών
typedef struct {
    int accountNumber;        // Αριθμός λογαριασμού
    int departmentNumber;     // Αριθμός τμήματος για τη διάκριση των λογαριασμών
    float balance;            // Υπόλοιπο του λογαριασμού
    pthread_mutex_t lock;     // Κλείδωμα mutex για αποφυγή ταυτόχρονων τροποποιήσεων (eager locking)
} Account;

Account accounts[MAX_ACCOUNTS]; // Πίνακας για αποθήκευση λογαριασμών
int num_accounts = 0;          // Αριθμός λογαριασμών που έχουν φορτωθεί

// Συνάρτηση για φόρτωση λογαριασμών από αρχείο
void load_accounts(const char *filename) {
    FILE *file = fopen(filename, "r");  // Άνοιγμα αρχείου σε λειτουργία ανάγνωσης
    if (!file) {
        perror("Failed to open account file");  // Εμφάνιση σφάλματος αν δεν ανοίξει το αρχείο
        exit(EXIT_FAILURE);  // Έξοδος σε περίπτωση αποτυχίας
    }

    // Διαβάζει τα δεδομένα λογαριασμών από το αρχείο
    while (fscanf(file, "%d,%d,%f", &accounts[num_accounts].accountNumber, 
                  &accounts[num_accounts].departmentNumber, &accounts[num_accounts].balance) == 3) {
        pthread_mutex_init(&accounts[num_accounts].lock, NULL);  // Αρχικοποίηση του mutex για κάθε λογαριασμό
        num_accounts++;  // Αύξηση του μετρητή λογαριασμών
        if (num_accounts >= MAX_ACCOUNTS) break;  // Έλεγχος για υπέρβαση του μέγιστου αριθμού λογαριασμών
    }

    fclose(file);  // Κλείσιμο του αρχείου μετά τη φόρτωση
    printf("Loaded %d accounts from '%s'.\n", num_accounts, filename);  // Εκτύπωση επιβεβαίωσης φόρτωσης
}

// Συνάρτηση για αποθήκευση των ενημερωμένων υπολοίπων σε αρχείο
void save_accounts(const char *filename) {
    FILE *file = fopen(filename, "w");  // Άνοιγμα αρχείου σε λειτουργία εγγραφής
    if (!file) {
        perror("Failed to open account file for writing");  // Εμφάνιση σφάλματος αν δεν ανοίξει το αρχείο
        return;  // Επιστροφή αν αποτύχει το άνοιγμα
    }

    // Εγγραφή των λογαριασμών στο αρχείο
    for (int i = 0; i < num_accounts; i++) {
        fprintf(file, "%d,%d,%.2f\n", accounts[i].accountNumber, accounts[i].departmentNumber, accounts[i].balance);
    }

    fclose(file);  // Κλείσιμο του αρχείου μετά την εγγραφή
}

// Συνάρτηση για εύρεση λογαριασμού με βάση το τμήμα και τον αριθμό λογαριασμού
Account* find_account(int departmentNumber, int accountNumber) {
    // Έλεγχος για τον λογαριασμό που αντιστοιχεί στο τμήμα και τον αριθμό λογαριασμού
    for (int i = 0; i < num_accounts; i++) {
        if (accounts[i].accountNumber == accountNumber && accounts[i].departmentNumber == departmentNumber) {
            return &accounts[i];  // Επιστροφή δείκτη στον λογαριασμό
        }
    }
    return NULL;  // Επιστροφή NULL αν δεν βρεθεί ο λογαριασμός
}

// Συνάρτηση για επεξεργασία εισερχόμενου ερωτήματος
void process_query(int client_sock, char *query) {
    int department, query_type, accountA, accountB;  // Μεταβλητές για το τμήμα, τον τύπο ερωτήματος και τους λογαριασμούς
    float amount;  // Μεταβλητή για ποσό χρημάτων
    char response[BUFFER_SIZE];  // Απάντηση που θα σταλεί πίσω στον πελάτη

    // Ανάλυση του ερωτήματος
    if (sscanf(query, "Department: %d, Query Type: %d, Account: %d", &department, &query_type, &accountA) < 2) {
        snprintf(response, sizeof(response), "Invalid query format: %s\n", query);  // Μήνυμα σφάλματος για λάθος μορφή ερωτήματος
        send(client_sock, response, strlen(response), 0);  // Αποστολή του μηνύματος στον πελάτη
        return;
    }

    Account *accA, *accB;  // Δείκτες στους λογαριασμούς A και B

    switch (query_type) {
        case 1:  // Ερώτημα τύπου 1: Έλεγχος υπολοίπου λογαριασμού
            accA = find_account(department, accountA);  // Εύρεση του λογαριασμού
            if (accA) {
                snprintf(response, sizeof(response), "Account %d (Dept %d) balance: %.2f\n", accA->accountNumber, accA->departmentNumber, accA->balance);  // Επιστροφή υπολοίπου
            } else {
                snprintf(response, sizeof(response), "Account %d not found in Central Server\n", accountA);  // Μήνυμα σφάλματος αν δεν βρεθεί ο λογαριασμός
            }
            send(client_sock, response, strlen(response), 0);  // Αποστολή της απάντησης στον πελάτη
            break;

        case 2:  // Ερώτημα τύπου 2: Προσθήκη/Αφαίρεση χρημάτων από λογαριασμό
            if (sscanf(query, "Department: %d, Query Type: %d, Account: %d, Amount: %f", &department, &query_type, &accountA, &amount) == 4) {
                accA = find_account(department, accountA);  // Εύρεση του λογαριασμού
                if (accA) {
                    pthread_mutex_lock(&accA->lock);  // Κλείδωμα του λογαριασμού για ενημέρωση
                    accA->balance += amount;  // Προσθήκη ή αφαίρεση του ποσού
                    snprintf(response, sizeof(response), "Account %d updated. New balance: %.2f\n", accA->accountNumber, accA->balance);  // Ενημέρωση του νέου υπολοίπου
                    save_accounts("accounts.txt");  // Αποθήκευση των ενημερωμένων υπολοίπων στο αρχείο
                    pthread_mutex_unlock(&accA->lock);  // Ξεκλείδωμα του λογαριασμού
                } else {
                    snprintf(response, sizeof(response), "Account %d not found in Central Server\n", accountA);  // Μήνυμα σφάλματος αν δεν βρεθεί ο λογαριασμός
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for add/remove money: %s\n", query);  // Μήνυμα σφάλματος για λάθος μορφή ερωτήματος
            }
            send(client_sock, response, strlen(response), 0);  // Αποστολή της απάντησης στον πελάτη
            break;

        case 3:  // Ερώτημα τύπου 3: Μεταφορά χρημάτων μεταξύ λογαριασμών
            if (sscanf(query, "Department: %d, Query Type: %d, Account A: %d, Account B: %d, Amount: %f", &department, &query_type, &accountA, &accountB, &amount) == 5) {
                accA = find_account(department, accountA);  // Εύρεση λογαριασμού Α
                accB = find_account(department, accountB);  // Εύρεση λογαριασμού Β
                if (accA && accB) {
                    pthread_mutex_lock(&accA->lock);  // Κλείδωμα λογαριασμού Α
                    pthread_mutex_lock(&accB->lock);  // Κλείδωμα λογαριασμού Β
                    if (accA->balance >= amount) {  // Έλεγχος αν ο λογαριασμός Α έχει αρκετά χρήματα
                        accA->balance -= amount;  // Αφαίρεση του ποσού από τον λογαριασμό Α
                        accB->balance += amount;  // Προσθήκη του ποσού στον λογαριασμό Β
                        snprintf(response, sizeof(response), "Transferred %.2f from Account %d to Account %d\n", amount, accA->accountNumber, accB->accountNumber);  // Μήνυμα επιβεβαίωσης
                        save_accounts("accounts.txt");  // Αποθήκευση των ενημερωμένων υπολοίπων στο αρχείο
                    } else {
                        snprintf(response, sizeof(response), "Insufficient funds in Account %d\n", accA->accountNumber);  // Μήνυμα σφάλματος για ανεπαρκές υπόλοιπο
                    }
                    pthread_mutex_unlock(&accB->lock);  // Ξεκλείδωμα λογαριασμού Β
                    pthread_mutex_unlock(&accA->lock);  // Ξεκλείδωμα λογαριασμού Α
                } else {
                    snprintf(response, sizeof(response), "One or both accounts not found in Central Server\n");  // Μήνυμα σφάλματος αν δεν βρεθούν οι λογαριασμοί
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for transfer: %s\n", query);  // Μήνυμα σφάλματος για λάθος μορφή ερωτήματος
            }
            send(client_sock, response, strlen(response), 0);  // Αποστολή της απάντησης στον πελάτη
            break;

        default:
            snprintf(response, sizeof(response), "Unknown query type: %d\n", query_type);  // Μήνυμα σφάλματος για άγνωστο τύπο ερωτήματος
            send(client_sock, response, strlen(response), 0);  // Αποστολή της απάντησης στον πελάτη
            break;
    }
}

// Συνάρτηση για χειρισμό εισερχόμενων συνδέσεων από τοπικούς servers
void *handle_client(void *socket_desc) {
    int client_sock = *(int *)socket_desc;  // Λήψη του socket του πελάτη
    free(socket_desc);  // Απελευθέρωση της δυναμικά δεσμευμένης μνήμης
    char buffer[BUFFER_SIZE];  // Buffer για αποθήκευση του εισερχόμενου ερωτήματος
    ssize_t read_size;

    // Συνεχής λήψη και επεξεργασία ερωτημάτων από τον τοπικό server
    while ((read_size = recv(client_sock, buffer, BUFFER_SIZE, 0)) > 0) {
        buffer[read_size] = '\0';  // Προσθήκη null-terminator για το τέλος της συμβολοσειράς
        process_query(client_sock, buffer);  // Επεξεργασία του ερωτήματος και αποστολή της απάντησης πίσω
    }

    if (read_size == 0) {
        // Ο πελάτης έκλεισε τη σύνδεση
    } else if (read_size == -1) {
        perror("recv failed");  // Μήνυμα σφάλματος αν αποτύχει η λήψη δεδομένων
    }

    close(client_sock);  // Κλείσιμο της σύνδεσης
    return NULL;  // Επιστροφή NULL στο τέλος της συνάρτησης νήματος
}

int main() {
    int server_sock, client_sock, *new_sock;
    struct sockaddr_in server, client;  // Δομές για τις διευθύνσεις του server και του πελάτη
    socklen_t client_len = sizeof(client);  // Μέγεθος της δομής client

    // Φόρτωση λογαριασμών από το αρχείο (π.χ. accounts.txt)
    load_accounts("accounts.txt");  // Φόρτωση των υπολοίπων λογαριασμών όλων των τμημάτων

    // Δημιουργία socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);  // Δημιουργία socket TCP
    if (server_sock == -1) {
        perror("Could not create socket");  // Μήνυμα σφάλματος αν αποτύχει η δημιουργία του socket
        exit(EXIT_FAILURE);  // Έξοδος σε περίπτωση αποτυχίας
    }
    printf("Central server socket created.\n");

    // Προετοιμασία της δομής sockaddr_in
    server.sin_family = AF_INET;  // Ορισμός του πρωτοκόλλου ως IPv4
    server.sin_addr.s_addr = INADDR_ANY;  // Ο server δέχεται συνδέσεις από οποιαδήποτε διεύθυνση
    server.sin_port = htons(CENTRAL_PORT);  // Μετατροπή της θύρας σε μορφή δικτύου

    // Δέσμευση της διεύθυνσης στο socket
    if (bind(server_sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Bind failed");  // Μήνυμα σφάλματος αν αποτύχει η δέσμευση
        close(server_sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);  // Έξοδος σε περίπτωση αποτυχίας
    }
    printf("Central server bind done.\n");

    // Αναμονή για εισερχόμενες συνδέσεις
    listen(server_sock, 3);  // Ορισμός του socket σε λειτουργία αναμονής για 3 συνδέσεις ταυτόχρονα
    printf("Central server waiting for incoming connections...\n");

    // Αποδοχή εισερχόμενων συνδέσεων
    while ((client_sock = accept(server_sock, (struct sockaddr *)&client, &client_len))) {

        // Δημιουργία νέου νήματος για κάθε σύνδεση από τοπικό server
        pthread_t client_thread;
        new_sock = malloc(1);  // Δέσμευση δυναμικής μνήμης για το socket
        *new_sock = client_sock;  // Αντιγραφή του socket του πελάτη στη νέα θέση μνήμης

        if (pthread_create(&client_thread, NULL, handle_client, (void *)new_sock) < 0) {
            perror("Could not create thread");  // Μήνυμα σφάλματος αν αποτύχει η δημιουργία του νήματος
            close(client_sock);  // Κλείσιμο του socket του πελάτη
            continue;
        }
    }

    if (client_sock < 0) {
        perror("Accept failed");  // Μήνυμα σφάλματος αν αποτύχει η αποδοχή σύνδεσης
        close(server_sock);  // Κλείσιμο του socket του server
        exit(EXIT_FAILURE);  // Έξοδος σε περίπτωση αποτυχίας
    }

    close(server_sock);  // Κλείσιμο του socket του server
    return 0;  // Επιστροφή επιτυχίας
}

