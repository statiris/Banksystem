#include <stdio.h>    // Βιβλιοθήκη για είσοδο/έξοδο δεδομένων (π.χ., printf, scanf)
#include <stdlib.h>   // Βιβλιοθήκη για γενικές συναρτήσεις όπως malloc, exit κλπ.
#include <string.h>   // Βιβλιοθήκη για χειρισμό συμβολοσειρών (π.χ., strcpy, strlen)
#include <unistd.h>   // Βιβλιοθήκη για συστήματα Unix (π.χ., close, sleep)
#include <arpa/inet.h> // Βιβλιοθήκη για χειρισμό δικτύου, όπως sockets και διευθύνσεις IP
#include <pthread.h>  // Βιβλιοθήκη για πολυνημάτωση (π.χ., δημιουργία και διαχείριση threads)
#include <time.h>     // Βιβλιοθήκη για χειρισμό ημερομηνιών και χρόνου

#define LOCAL_PORT 8080  // Θύρα για τον τοπικό server του Τμήματος 1
#define CENTRAL_SERVER_IP "127.0.0.1"  // IP διεύθυνση του κεντρικού server
#define CENTRAL_SERVER_PORT 8081  // Θύρα του κεντρικού server
#define BUFFER_SIZE 1024  // Μέγεθος του buffer για την επικοινωνία
#define MAX_ACCOUNTS 500  // Μέγιστος αριθμός λογαριασμών που μπορεί να χειριστεί ο server

// Δομή για αποθήκευση δεδομένων λογαριασμού
typedef struct {
    int accountNumber;  // Αριθμός λογαριασμού
    float balance;  // Υπόλοιπο λογαριασμού
    pthread_mutex_t lock;  // Mutex για τον συγχρονισμό πρόσβασης στον λογαριασμό
} Account;

Account accounts[MAX_ACCOUNTS];  // Πίνακας με τους λογαριασμούς
int num_accounts = 0;  // Αριθμός λογαριασμών που έχουν φορτωθεί

// Συνάρτηση για την φόρτωση των λογαριασμών από αρχείο
void load_accounts(const char *filename) {
    FILE *file = fopen(filename, "r");  // Άνοιγμα αρχείου για ανάγνωση
    if (!file) {  // Έλεγχος αν το άνοιγμα του αρχείου απέτυχε
        perror("Failed to open account file");  // Εμφάνιση μηνύματος λάθους
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }

    // Διαβάζει τους αριθμούς λογαριασμών και τα υπόλοιπά τους από το αρχείο
    while (fscanf(file, "%d,%f", &accounts[num_accounts].accountNumber, &accounts[num_accounts].balance) == 2) {
        pthread_mutex_init(&accounts[num_accounts].lock, NULL);  // Αρχικοποίηση του mutex για τον λογαριασμό
        num_accounts++;  // Αύξηση του αριθμού λογαριασμών
        if (num_accounts >= MAX_ACCOUNTS) break;  // Διακοπή αν φτάσουμε στο μέγιστο αριθμό λογαριασμών
    }

    fclose(file);  // Κλείσιμο του αρχείου
    printf("Loaded %d accounts from '%s'.\n", num_accounts, filename);  // Εμφάνιση μηνύματος επιβεβαίωσης
}

// Συνάρτηση για αποθήκευση των ενημερωμένων λογαριασμών σε αρχείο
void save_accounts(const char *filename) {
    FILE *file = fopen(filename, "w");  // Άνοιγμα αρχείου για εγγραφή
    if (!file) {  // Έλεγχος αν το άνοιγμα του αρχείου απέτυχε
        perror("Failed to open account file for writing");  // Εμφάνιση μηνύματος λάθους
        return;  // Επιστροφή χωρίς να γίνει τίποτα άλλο
    }

    // Εγγραφή των λογαριασμών και των υπολοίπων τους στο αρχείο
    for (int i = 0; i < num_accounts; i++) {
        fprintf(file, "%d,%.2f\n", accounts[i].accountNumber, accounts[i].balance);
    }

    fclose(file);  // Κλείσιμο του αρχείου
}

// Συνάρτηση για την εύρεση λογαριασμού βάσει αριθμού λογαριασμού
Account* find_account(int accountNumber) {
    for (int i = 0; i < num_accounts; i++) {  // Διατρέχει όλους τους λογαριασμούς
        if (accounts[i].accountNumber == accountNumber) {  // Έλεγχος αν βρέθηκε ο λογαριασμός
            return &accounts[i];  // Επιστροφή δείκτη στον λογαριασμό
        }
    }
    return NULL;  // Επιστροφή NULL αν ο λογαριασμός δεν βρέθηκε
}

// Συνάρτηση για την προώθηση αιτήματος στον κεντρικό server
void forward_to_central_server(char *query, int client_sock) {
    int central_sock;  // Socket για σύνδεση με τον κεντρικό server
    struct sockaddr_in central_server_addr;  // Δομή για την διεύθυνση του κεντρικού server

    // Δημιουργία socket για TCP σύνδεση
    central_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (central_sock < 0) {  // Έλεγχος αν απέτυχε η δημιουργία του socket
        perror("Socket creation error");  // Εμφάνιση μηνύματος λάθους
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }

    // Ρύθμιση διεύθυνσης του κεντρικού server
    central_server_addr.sin_family = AF_INET;  // Χρήση IPv4
    central_server_addr.sin_port = htons(CENTRAL_SERVER_PORT);  // Μετατροπή θύρας σε μορφή δικτύου

    // Μετατροπή της IP διεύθυνσης σε μορφή που καταλαβαίνει το δίκτυο
    if (inet_pton(AF_INET, CENTRAL_SERVER_IP, &central_server_addr.sin_addr) <= 0) {
        perror("Invalid address/Address not supported");  // Εμφάνιση λάθους αν η IP δεν είναι έγκυρη
        close(central_sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }

    // Σύνδεση με τον κεντρικό server
    if (connect(central_sock, (struct sockaddr *)&central_server_addr, sizeof(central_server_addr)) < 0) {
        perror("Connection to central server failed");  // Εμφάνιση μηνύματος λάθους
        close(central_sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }

    // Αποστολή του αιτήματος στον κεντρικό server
    send(central_sock, query, strlen(query), 0);

    // Λήψη απάντησης από τον κεντρικό server
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received = recv(central_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {  // Έλεγχος αν ελήφθησαν δεδομένα
        buffer[bytes_received] = '\0';  // Προσθήκη του τερματικού χαρακτήρα στο τέλος των δεδομένων
        send(client_sock, buffer, strlen(buffer), 0);  // Αποστολή της απάντησης στον πελάτη
    }

    // Κλείσιμο της σύνδεσης με τον κεντρικό server
    close(central_sock);
}

// Συνάρτηση για επεξεργασία αιτήματος και αποστολή απάντησης στον πελάτη
void process_query(int client_sock, char *query) {
    int department, query_type, accountA, accountB;
    float amount;
    char response[BUFFER_SIZE];

    // Ανάλυση της μορφής του αιτήματος
    if (sscanf(query, "Department: %d, Query Type: %d, Account: %d", &department, &query_type, &accountA) < 2) {
        snprintf(response, sizeof(response), "Invalid query format: %s\n", query);  // Εμφάνιση μηνύματος λάθους αν η μορφή του αιτήματος δεν είναι έγκυρη
        send(client_sock, response, strlen(response), 0);
        return;
    }

    Account *accA, *accB;

    // Έλεγχος αν ο λογαριασμός ανήκει στο Τμήμα 1 (τοπικοί λογαριασμοί)
    accA = find_account(accountA);
    if (accA == NULL && department == 1) {  // Αν δεν βρεθεί ο λογαριασμός, προώθηση στον κεντρικό server
        forward_to_central_server(query, client_sock);
        return;
    }

    // Επεξεργασία αιτημάτων για το Τμήμα 1
    switch (query_type) {
        case 1:  // Έλεγχος υπολοίπου λογαριασμού
            if (accA) {  // Αν ο λογαριασμός βρεθεί
                snprintf(response, sizeof(response), "Account %d balance: %.2f\n", accA->accountNumber, accA->balance);  // Δημιουργία απάντησης
            }
            send(client_sock, response, strlen(response), 0);  // Αποστολή απάντησης στον πελάτη
            break;

        case 2:  // Προσθήκη/Αφαίρεση χρημάτων από λογαριασμό
            if (sscanf(query, "Department: %d, Query Type: %d, Account: %d, Amount: %f", &department, &query_type, &accountA, &amount) == 4) {
                if (accA) {  // Αν ο λογαριασμός βρεθεί
                    pthread_mutex_lock(&accA->lock);  // Κλείδωμα του λογαριασμού για τροποποίηση
                    accA->balance += amount;  // Ενημέρωση του υπολοίπου
                    snprintf(response, sizeof(response), "Account %d updated. New balance: %.2f\n", accA->accountNumber, accA->balance);  // Δημιουργία απάντησης
                    save_accounts("dep1_accounts.txt");  // Αποθήκευση των ενημερωμένων λογαριασμών στο αρχείο
                    pthread_mutex_unlock(&accA->lock);  // Ξεκλείδωμα του λογαριασμού
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for add/remove money: %s\n", query);  // Εμφάνιση μηνύματος λάθους αν η μορφή είναι λάθος
            }
            send(client_sock, response, strlen(response), 0);  // Αποστολή απάντησης στον πελάτη
            break;

        case 3:  // Μεταφορά χρημάτων από λογαριασμό Α σε λογαριασμό Β (τοπικές μεταφορές)
            if (sscanf(query, "Department: %d, Query Type: %d, Account A: %d, Account B: %d, Amount: %f", &department, &query_type, &accountA, &accountB, &amount) == 5) {
                accA = find_account(accountA);  // Εύρεση λογαριασμού Α
                accB = find_account(accountB);  // Εύρεση λογαριασμού Β
                if (accA && accB) {  // Αν βρεθούν και οι δύο λογαριασμοί
                    pthread_mutex_lock(&accA->lock);  // Κλείδωμα λογαριασμού Α
                    pthread_mutex_lock(&accB->lock);  // Κλείδωμα λογαριασμού Β
                    if (accA->balance >= amount) {  // Έλεγχος αν ο λογαριασμός Α έχει επαρκές υπόλοιπο
                        accA->balance -= amount;  // Αφαίρεση ποσού από τον λογαριασμό Α
                        accB->balance += amount;  // Προσθήκη ποσού στον λογαριασμό Β
                        snprintf(response, sizeof(response), "Transferred %.2f from Account %d to Account %d\n", amount, accA->accountNumber, accB->accountNumber);  // Δημιουργία απάντησης
                        save_accounts("dep1_accounts.txt");  // Αποθήκευση των ενημερωμένων λογαριασμών στο αρχείο
                    } else {
                        snprintf(response, sizeof(response), "Insufficient funds in Account %d\n", accA->accountNumber);  // Μήνυμα για ανεπαρκές υπόλοιπο
                    }
                    pthread_mutex_unlock(&accB->lock);  // Ξεκλείδωμα λογαριασμού Β
                    pthread_mutex_unlock(&accA->lock);  // Ξεκλείδωμα λογαριασμού Α
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for transfer: %s\n", query);  // Εμφάνιση μηνύματος λάθους αν η μορφή είναι λάθος
            }
            send(client_sock, response, strlen(response), 0);  // Αποστολή απάντησης στον πελάτη
            break;

        case 4:  // Εμφάνιση μέσου υπολοίπου λογαριασμών με timestamp
            {
                float total_balance = 0;  // Μεταβλητή για το συνολικό υπόλοιπο
                for (int i = 0; i < num_accounts; i++) {
                    total_balance += accounts[i].balance;  // Υπολογισμός του συνολικού υπολοίπου
                }
                float average_balance = total_balance / num_accounts;  // Υπολογισμός του μέσου όρου

                time_t now = time(NULL);  // Λήψη της τρέχουσας ώρας
                char timestamp[64];  // Μικρότερο buffer για το timestamp
                strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", localtime(&now));  // Δημιουργία της μορφής του timestamp

                int len = snprintf(response, sizeof(response), "Average balance for Department 1: %.2f\n", average_balance);  // Δημιουργία απάντησης για τον μέσο όρο
                snprintf(response + len, sizeof(response) - len, "Timestamp: %s\n", timestamp);  // Προσθήκη του timestamp στην απάντηση

                send(client_sock, response, strlen(response), 0);  // Αποστολή απάντησης στον πελάτη
            }
            break;

        default:
            snprintf(response, sizeof(response), "Unknown query type: %d\n", query_type);  // Μήνυμα για άγνωστο τύπο αιτήματος
            send(client_sock, response, strlen(response), 0);  // Αποστολή του μηνύματος στον πελάτη
            break;
    }
}

// Συνάρτηση για χειρισμό εισερχόμενων συνδέσεων από πελάτες
void *handle_client(void *socket_desc) {
    int client_sock = *(int *)socket_desc;  // Λήψη του socket του πελάτη
    free(socket_desc);  // Απελευθέρωση της μνήμης που καταλαμβάνεται από το socket_desc
    char buffer[BUFFER_SIZE];  // Buffer για την αποθήκευση του αιτήματος
    ssize_t read_size;

    // Συνεχής λήψη και επεξεργασία αιτημάτων από τον πελάτη
    while ((read_size = recv(client_sock, buffer, BUFFER_SIZE, 0)) > 0) {
        buffer[read_size] = '\0';  // Προσθήκη τερματικού χαρακτήρα στο τέλος των δεδομένων
        process_query(client_sock, buffer);  // Επεξεργασία του αιτήματος
    }

    if (read_size == 0) {  // Έλεγχος αν ο πελάτης αποσυνδέθηκε
        printf("Client disconnected.\n");
    } else if (read_size == -1) {  // Έλεγχος αν απέτυχε η λήψη δεδομένων
        perror("recv failed");  // Εμφάνιση μηνύματος λάθους
    }

    close(client_sock);  // Κλείσιμο του socket του πελάτη
    return NULL;  // Επιστροφή από το thread
}

int main() {
    int server_sock, client_sock, *new_sock;
    struct sockaddr_in server, client;  // Δομές για τη διεύθυνση του server και του πελάτη
    socklen_t client_len = sizeof(client);

    // Φόρτωση λογαριασμών από το αρχείο
    load_accounts("dep1_accounts.txt");  // Ανάγνωση των αρχικών υπολοίπων λογαριασμών

    // Δημιουργία του socket του server
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {  // Έλεγχος αν απέτυχε η δημιουργία του socket
        perror("Could not create socket");  // Εμφάνιση μηνύματος λάθους
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }
    printf("Department 1 server socket created.\n");

    // Προετοιμασία της δομής sockaddr_in για τον server
    server.sin_family = AF_INET;  // Χρήση IPv4
    server.sin_addr.s_addr = INADDR_ANY;  // Χρήση οποιασδήποτε διαθέσιμης διεύθυνσης IP
    server.sin_port = htons(LOCAL_PORT);  // Μετατροπή της τοπικής θύρας σε μορφή δικτύου

    // Δέσμευση της διεύθυνσης και θύρας του server
    if (bind(server_sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Department 1 server bind failed");  // Εμφάνιση μηνύματος λάθους αν αποτύχει η δέσμευση
        close(server_sock);  // Κλείσιμο του socket
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }
    printf("Department 1 server bind done.\n");

    // Αναμονή για εισερχόμενες συνδέσεις
    listen(server_sock, 3);  // Ακρόαση για μέχρι 3 συνδέσεις ταυτόχρονα
    printf("Department 1 server waiting for incoming connections...\n");

    // Αποδοχή εισερχόμενων συνδέσεων
    while ((client_sock = accept(server_sock, (struct sockaddr *)&client, &client_len))) {
        printf("Connection accepted.\n");

        // Δημιουργία νέου thread για κάθε πελάτη
        pthread_t client_thread;
        new_sock = malloc(1);  // Δέσμευση μνήμης για το νέο socket
        *new_sock = client_sock;  // Αποθήκευση του socket του πελάτη

        if (pthread_create(&client_thread, NULL, handle_client, (void *)new_sock) < 0) {  // Δημιουργία thread για το χειρισμό του πελάτη
            perror("Could not create thread");  // Εμφάνιση μηνύματος λάθους αν αποτύχει η δημιουργία thread
            close(client_sock);  // Κλείσιμο του socket του πελάτη
            continue;  // Συνεχίζει για τον επόμενο πελάτη
        }

        printf("Handler assigned.\n");  // Εμφάνιση μηνύματος επιτυχίας
    }

    if (client_sock < 0) {  // Έλεγχος αν απέτυχε η αποδοχή σύνδεσης
        perror("Accept failed");  // Εμφάνιση μηνύματος λάθους
        close(server_sock);  // Κλείσιμο του socket του server
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα με αποτυχία
    }

    close(server_sock);  // Κλείσιμο του socket του server
    return 0;  // Επιτυχής έξοδος από το πρόγραμμα
}

