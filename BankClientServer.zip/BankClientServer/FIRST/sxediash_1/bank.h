// bank.h
#ifndef BANK_H        // Ασφάλεια για να μην συμπεριληφθεί το header file πολλαπλές φορές
#define BANK_H        // Ορισμός της ασφάλειας συμπερίληψης

// Απαραίτητες βιβλιοθήκες
#include <stdio.h>    // Βιβλιοθήκη για εισαγωγή/εξαγωγή δεδομένων (I/O) και λειτουργίες αρχείων
#include <stdlib.h>   // Βιβλιοθήκη για λειτουργίες διαχείρισης μνήμης, τυχαίους αριθμούς κ.λπ.
#include <string.h>   // Βιβλιοθήκη για χειρισμό συμβολοσειρών (string), π.χ., strcpy, strcmp κ.λπ.
#include <pthread.h>  // Βιβλιοθήκη για χρήση POSIX threads (υποστήριξη πολυνηματικότητας)
#include <unistd.h>   // Βιβλιοθήκη για διάφορες λειτουργίες όπως sleep
#include <time.h>     // Βιβλιοθήκη για χειρισμό χρόνου, π.χ., λήψη της τρέχουσας ώρας

// Ορισμοί
#define NUM_ACCOUNTS 1000  // Ο αριθμός των λογαριασμών στο σύστημα
#define DEPARTMENT_1 1     // Μακροεντολή που αντιπροσωπεύει το τμήμα 1
#define DEPARTMENT_2 2     // Μακροεντολή που αντιπροσωπεύει το τμήμα 2

// Δομή για την αναπαράσταση ενός λογαριασμού
typedef struct {
    int accountNumber;         // Μοναδικός αριθμός λογαριασμού για ταυτοποίηση
    unsigned char departmentNumber; // Αριθμός τμήματος (π.χ. 1 ή 2)
    float amount;              // Υπόλοιπο του λογαριασμού
} Account;                     // Τερματισμός της δομής Account

// Δομή για τη διαχείριση αιτημάτων πελατών
typedef struct {
    int departmentNumber;  // Αριθμός τμήματος που κάνει το αίτημα
    int queryType;         // Τύπος αιτήματος (π.χ. έλεγχος υπολοίπου, μεταφορά κ.λπ.)
    int accountNumberA;    // Πρώτος αριθμός λογαριασμού (λογαριασμός προέλευσης σε περίπτωση μεταφοράς)
    int accountNumberB;    // Δεύτερος αριθμός λογαριασμού (λογαριασμός προορισμού σε περίπτωση μεταφοράς)
    float amount;          // Ποσό χρημάτων που αφορά το αίτημα
} Request;                // Τερματισμός της δομής Request

// Δηλώσεις συναρτήσεων
void initialize_accounts();   // Αρχικοποιεί όλους τους λογαριασμούς με προεπιλεγμένες τιμές (π.χ. μηδενικό υπόλοιπο)
float get_balance(int accountNumber);   // Επιστρέφει το υπόλοιπο του καθορισμένου λογαριασμού
float update_balance(int accountNumber, float amount);   // Ενημερώνει το υπόλοιπο του καθορισμένου λογαριασμού με δεδομένο ποσό (θετικό ή αρνητικό)
void transfer_money(int accountNumberA, int accountNumberB, float amount);   // Μεταφέρει χρήματα από έναν λογαριασμό (accountNumberA) σε έναν άλλο (accountNumberB)
float calculate_average(unsigned char departmentNumber);   // Υπολογίζει το μέσο υπόλοιπο όλων των λογαριασμών σε ένα συγκεκριμένο τμήμα
void lock_account(int accountNumber);   // Κλειδώνει έναν λογαριασμό ώστε κανένα άλλο νήμα να μην μπορεί να τον τροποποιήσει (ασφάλεια πολυνηματικότητας)
void unlock_account(int accountNumber);   // Ξεκλειδώνει έναν λογαριασμό, επιτρέποντας σε άλλα νήματα να έχουν πρόσβαση σε αυτόν
void save_accounts_to_file();   // Αποθηκεύει την κατάσταση όλων των λογαριασμών σε ένα αρχείο (για διατήρηση δεδομένων)
void send_final_accounts_to_client(int client_socket, int departmentNumber);   // Στέλνει την τελική κατάσταση όλων των λογαριασμών σε ένα συγκεκριμένο τμήμα στον πελάτη μέσω σύνδεσης socket

#endif  // Τέλος της ασφάλειας συμπερίληψης

