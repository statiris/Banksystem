#include "bank.h"  // Εισαγωγή της επικεφαλίδας "bank.h" που περιέχει τους ορισμούς των λογαριασμών και άλλων συναρτήσεων
#include <sys/socket.h>  // Εισαγωγή της βιβλιοθήκης για δημιουργία sockets
#include <arpa/inet.h>  // Εισαγωγή της βιβλιοθήκης για λειτουργίες με IP διευθύνσεις και πρωτόκολλο Internet
#include <pthread.h>  // Εισαγωγή της βιβλιοθήκης για την υποστήριξη πολυνηματισμού (multithreading)
#include <unistd.h>  // Εισαγωγή βασικών συστημικών συναρτήσεων όπως το close()

#define PORT 8080  // Ορισμός της θύρας 8080 για τον server
#define BUFFER_SIZE 1024  // Ορισμός του μεγέθους buffer για την επικοινωνία με τον πελάτη
#define MAX_CLIENTS 2  // Μέγιστος αριθμός ταυτόχρονων πελατών που επιτρέπονται

int clients_done = 0;  // Μεταβλητή που μετράει πόσοι πελάτες έχουν ολοκληρώσει τις συναλλαγές τους
pthread_mutex_t account_locks[NUM_ACCOUNTS];  // Δημιουργία mutex για κάθε λογαριασμό για αποφυγή συγχρονιστικών προβλημάτων
pthread_rwlock_t department_lock;  // Δημιουργία read-write lock για τα τμήματα (departments)
Account accounts[NUM_ACCOUNTS];  // Πίνακας που περιέχει τους λογαριασμούς (Account structs) για κάθε λογαριασμό

void write_initial_balances_to_file() {  // Συνάρτηση που γράφει τα αρχικά υπόλοιπα των λογαριασμών σε αρχείο
    FILE *file = fopen("initial_account_balances.txt", "w");  // Δημιουργεί ένα αρχείο για να γράψει τα αρχικά υπόλοιπα
    if (file == NULL) {  // Έλεγχος αν το αρχείο δεν μπόρεσε να δημιουργηθεί
        perror("Unable to create initial balances file");  // Εκτύπωση μηνύματος λάθους αν η δημιουργία αποτύχει
        exit(EXIT_FAILURE);  // Έξοδος από το πρόγραμμα σε περίπτωση σφάλματος
    }
    for (int i = 0; i < NUM_ACCOUNTS; i++) {  // Επανάληψη για κάθε λογαριασμό ώστε να γράψει τα δεδομένα του σε αρχείο
        fprintf(file, "Account %d, Department %d, Initial Balance: %.2f\n", accounts[i].accountNumber, accounts[i].departmentNumber, accounts[i].amount);  // Γράφει τα δεδομένα του λογαριασμού στο αρχείο
    }
    fclose(file);  // Κλείνει το αρχείο μετά τη συγγραφή
    printf("Initial account balances written to 'initial_account_balances.txt'\n");  // Εκτύπωση μηνύματος επιτυχίας
}

void *client_handler(void *socket_desc) {  // Συνάρτηση που εξυπηρετεί τον πελάτη, εκτελείται σε διαφορετικό νήμα
    int sock = *(int *)socket_desc;  // Μετατροπή της διεύθυνσης του socket σε αριθμό socket
    int read_size;  // Μεταβλητή για το μέγεθος των δεδομένων που λαμβάνονται
    char client_message[BUFFER_SIZE];  // Πίνακας που αποθηκεύει τα μηνύματα του πελάτη
    Request request;  // Δομή που περιέχει τις αιτήσεις του πελάτη
    int request_count = 0;  // Μετρητής των αιτημάτων του πελάτη

    while ((read_size = recv(sock, client_message, BUFFER_SIZE, 0)) > 0) {  // Επανάληψη όσο λαμβάνονται δεδομένα από τον πελάτη
        sscanf(client_message, "%d %d %d %d %f", &request.departmentNumber, &request.queryType, &request.accountNumberA, &request.accountNumberB, &request.amount);  // Ανάλυση του μηνύματος και αποθήκευση των πεδίων της αίτησης
        if (request.queryType == 1 || request.queryType == 2) {  // Έλεγχος για τον τύπο της αίτησης (1: έλεγχος υπολοίπου, 2: ενημέρωση υπολοίπου)
            pthread_mutex_lock(&account_locks[request.accountNumberA - 1]);  // Κλείδωμα του σχετικού λογαριασμού για ασφάλεια στις πολλαπλές διεργασίες
            if (request.queryType == 1) {  // Αν το αίτημα είναι για έλεγχο υπολοίπου
                request.amount = accounts[request.accountNumberA - 1].amount;  // Επιστρέφει το υπόλοιπο του λογαριασμού
            } else if (request.queryType == 2) {  // Αν το αίτημα είναι για ενημέρωση υπολοίπου
                accounts[request.accountNumberA - 1].amount += request.amount;  // Προσθήκη του ποσού στο υπόλοιπο
                request.amount = accounts[request.accountNumberA - 1].amount;  // Ενημέρωση του ποσού που θα σταλεί πίσω στον πελάτη
            }
            pthread_mutex_unlock(&account_locks[request.accountNumberA - 1]);  // Ξεκλείδωμα του λογαριασμού μετά την επεξεργασία
        } else if (request.queryType == 3) {  // Αν το αίτημα είναι για μεταφορά χρημάτων μεταξύ δύο λογαριασμών
            if (request.accountNumberA != request.accountNumberB) {  // Έλεγχος αν οι δύο λογαριασμοί είναι διαφορετικοί
                if (request.accountNumberA < request.accountNumberB) {  // Κλείδωμα των λογαριασμών με σειρά για αποφυγή αδιεξόδων (deadlock)
                    pthread_mutex_lock(&account_locks[request.accountNumberA - 1]);  // Κλείδωμα του πρώτου λογαριασμού
                    pthread_mutex_lock(&account_locks[request.accountNumberB - 1]);  // Κλείδωμα του δεύτερου λογαριασμού
                } else {  // Αν ο δεύτερος λογαριασμός έχει μικρότερο αριθμό
                    pthread_mutex_lock(&account_locks[request.accountNumberB - 1]);  // Κλείδωμα του δεύτερου λογαριασμού
                    pthread_mutex_lock(&account_locks[request.accountNumberA - 1]);  // Κλείδωμα του πρώτου λογαριασμού
                }
                accounts[request.accountNumberA - 1].amount -= request.amount;  // Αφαίρεση του ποσού από τον πρώτο λογαριασμό
                accounts[request.accountNumberB - 1].amount += request.amount;  // Προσθήκη του ποσού στον δεύτερο λογαριασμό
                pthread_mutex_unlock(&account_locks[request.accountNumberA - 1]);  // Ξεκλείδωμα του πρώτου λογαριασμού
                pthread_mutex_unlock(&account_locks[request.accountNumberB - 1]);  // Ξεκλείδωμα του δεύτερου λογαριασμού
            }
        } else if (request.queryType == 4) {  // Αν το αίτημα είναι για υπολογισμό του μέσου όρου του τμήματος
            pthread_rwlock_rdlock(&department_lock);  // Κλείδωμα ολόκληρου του τμήματος για ανάγνωση
            float sum = 0;  // Μεταβλητή για την αποθήκευση του συνόλου των υπολοίπων
            int count = 0;  // Μετρητής για τον αριθμό των λογαριασμών στο τμήμα
            for (int i = 0; i < NUM_ACCOUNTS; i++) {  // Επανάληψη σε όλους τους λογαριασμούς για το τμήμα
                if (accounts[i].departmentNumber == request.departmentNumber) {  // Έλεγχος αν ο λογαριασμός ανήκει στο τμήμα
                    sum += accounts[i].amount;  // Πρόσθεση του υπολοίπου του λογαριασμού στο σύνολο
                    count++;  // Αύξηση του μετρητή για κάθε λογαριασμό του τμήματος
                }
            }
            request.amount = sum / count;  // Υπολογισμός του μέσου όρου υπολοίπων
            pthread_rwlock_unlock(&department_lock);  // Ξεκλείδωμα του τμήματος μετά την ανάγνωση
        }
        send(sock, &request, sizeof(Request), 0);  // Αποστολή της επεξεργασμένης αίτησης πίσω στον πελάτη
        request_count++;  // Αύξηση του μετρητή αιτημάτων
    }
    if (request_count == 300000) {  // Έλεγχος αν ο πελάτης έστειλε ακριβώς 300.000 αιτήματα
        printf("Client from department %d completed 300,000 requests.\n", request.departmentNumber);  // Εκτύπωση μηνύματος επιτυχίας
    } else {  // Αν ο πελάτης αποσυνδέθηκε πριν ολοκληρώσει
        printf("Client from department %d disconnected before sending 300,000 requests.\n", request.departmentNumber);  // Εκτύπωση μηνύματος για αποσύνδεση πριν τα 300.000 αιτήματα
    }
    free(socket_desc);  // Αποδέσμευση της μνήμης που δεσμεύθηκε για το socket
    return 0;  // Τέλος της συνάρτησης
}

int main() {  // Κύρια συνάρτηση
    int server_socket, client_socket, c;  // Μεταβλητές για τον server και τους πελάτες
    struct sockaddr_in server, client;  // Δομές για τη διεύθυνση του server και των πελατών

    srand(time(0));  // Αρχικοποίηση της τυχαίας γεννήτριας για την επιλογή αρχικών υπολοίπων
    for (int i = 0; i < NUM_ACCOUNTS; i++) {  // Επανάληψη για όλους τους λογαριασμούς
        accounts[i].accountNumber = i + 1;  // Ορισμός του αριθμού λογαριασμού
        accounts[i].departmentNumber = (i < 500) ? DEPARTMENT_1 : DEPARTMENT_2;  // Ανάθεση του λογαριασμού σε τμήμα
        accounts[i].amount = (float)(rand() % 9901 + 100);  // Δημιουργία τυχαίου υπολοίπου μεταξύ 100 και 10.000
        pthread_mutex_init(&account_locks[i], NULL);  // Αρχικοποίηση του mutex για τον λογαριασμό
    }

    pthread_rwlock_init(&department_lock, NULL);  // Αρχικοποίηση του read-write lock για τα τμήματα

    write_initial_balances_to_file();  // Κλήση της συνάρτησης για να γραφτούν τα αρχικά υπόλοιπα σε αρχείο

    server_socket = socket(AF_INET, SOCK_STREAM, 0);  // Δημιουργία του socket για τον server
    if (server_socket == -1) {  // Έλεγχος αν απέτυχε η δημιουργία του socket
        printf("Could not create socket");  // Εκτύπωση μηνύματος σφάλματος
        return 1;  // Τερματισμός με σφάλμα
    }

    server.sin_family = AF_INET;  // Ορισμός της οικογένειας διευθύνσεων (IPv4)
    server.sin_addr.s_addr = INADDR_ANY;  // Ορισμός της διεύθυνσης IP του server (δέχεται οποιαδήποτε)
    server.sin_port = htons(PORT);  // Ορισμός της θύρας του server

    if (bind(server_socket, (struct sockaddr *)&server, sizeof(server)) < 0) {  // Δέσμευση της διεύθυνσης και της θύρας στο socket
        perror("Bind failed");  // Εκτύπωση μηνύματος σφάλματος αν αποτύχει η δέσμευση
        return 1;  // Τερματισμός με σφάλμα
    }

    listen(server_socket, 3);  // Ο server αρχίζει να ακούει για συνδέσεις πελατών

    printf("Central server is running... Waiting for clients.\n");  // Εκτύπωση μηνύματος ότι ο server είναι έτοιμος

    c = sizeof(struct sockaddr_in);  // Μέγεθος της δομής διευθύνσεων για χρήση στο accept()

    while (clients_done < MAX_CLIENTS) {  // Επανάληψη όσο δεν έχουν ολοκληρώσει όλοι οι πελάτες
        client_socket = accept(server_socket, (struct sockaddr *)&client, (socklen_t *)&c);  // Αποδοχή νέας σύνδεσης πελάτη
        if (client_socket >= 0) {  // Έλεγχος αν η αποδοχή ήταν επιτυχής
            pthread_t client_thread;  // Δημιουργία νέου νήματος για τον πελάτη
            int *new_sock = malloc(sizeof(int));  // Δέσμευση μνήμης για το νέο socket
            *new_sock = client_socket;  // Αντιστοίχιση του socket πελάτη στη μεταβλητή

            if (pthread_create(&client_thread, NULL, client_handler, (void *)new_sock) < 0) {  // Δημιουργία του νήματος για τον πελάτη
                perror("Could not create thread");  // Εκτύπωση μηνύματος αν αποτύχει η δημιουργία του νήματος
                return 1;  // Τερματισμός με σφάλμα
            }

            pthread_detach(client_thread);  // Αποσύνδεση του νήματος για να απελευθερωθεί η μνήμη μετά την ολοκλήρωση
        }
    }

    close(server_socket);  // Κλείσιμο του server socket μετά την ολοκλήρωση
    return 0;  // Τερματισμός του προγράμματος
}

