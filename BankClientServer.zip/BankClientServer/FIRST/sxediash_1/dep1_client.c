#include "bank.h"  // Προσθήκη εξωτερικού header file "bank.h", πιθανώς για να περιλαμβάνει δηλώσεις και δομές που χρησιμοποιούνται στον κώδικα
#include <sys/socket.h>  // Βιβλιοθήκη για επικοινωνία μέσω sockets
#include <arpa/inet.h>  // Βιβλιοθήκη για την χρήση internet πρωτοκόλλων (π.χ. IP)
#include <unistd.h>  // Βιβλιοθήκη για την χρήση λειτουργιών συστήματος (π.χ. close())

#define PORT 8080  // Ορισμός σταθεράς PORT για τον αριθμό θύρας του server
#define WORKLOAD_SIZE 300000  // Σταθερά για το μέγεθος των αιτημάτων που θα δημιουργηθούν (300.000)
#define BUFFER_SIZE 1024  // Σταθερά για το μέγεθος του buffer

// Συνάρτηση για τη δημιουργία αρχείου workload
void generate_workload_file(const char* filename) {
    srand(time(0));  // Αρχικοποίηση του γεννήτριας τυχαίων αριθμών με βάση τον τρέχοντα χρόνο
    FILE *file = fopen(filename, "w");  // Άνοιγμα αρχείου για εγγραφή

    // Έλεγχος αν το αρχείο άνοιξε επιτυχώς
    if (file == NULL) {
        perror("Unable to open workload file");  // Εκτύπωση σφάλματος αν δεν ανοίξει
        exit(EXIT_FAILURE);  // Έξοδος με αποτυχία
    }

    // Επανάληψη για να δημιουργηθούν 300.000 γραμμές workload
    for (int i = 0; i < WORKLOAD_SIZE; i++) {
        int queryType;  // Μεταβλητή για τον τύπο αιτήματος
        int departmentNumber = DEPARTMENT_1;  // Ορισμός του τμήματος (Department 1)
        int accountA, accountB;  // Δύο λογαριασμοί που χρησιμοποιούνται σε ορισμένα αιτήματα
        float amount = (float)(rand() % 1000);  // Τυχαίο ποσό για ενημερώσεις ή μεταφορές

        int randomPercent = rand() % 100;  // Τυχαίος αριθμός για τον καθορισμό του τύπου του αιτήματος

        // Αν το randomPercent είναι κάτω από 35
        if (randomPercent < 35) {
            queryType = 1;  // Τύπος αιτήματος 1 (Ερώτηση Υπολοίπου)

            // 80% πιθανότητα να αφορά το ίδιο τμήμα (Department 1)
            if (rand() % 100 < 80) {
                accountA = rand() % 500 + 1;  // Τυχαίος λογαριασμός από 1 έως 500
            } else {
                // 20% πιθανότητα για άλλο τμήμα (Department 2)
                accountA = rand() % 500 + 501;  // Τυχαίος λογαριασμός από 501 έως 1000
            }
            fprintf(file, "%d %d %d\n", departmentNumber, queryType, accountA);  // Γράφει το αίτημα στο αρχείο

        } else if (randomPercent < 70) {
            queryType = 2;  // Τύπος αιτήματος 2 (Ενημέρωση Υπολοίπου)

            // 80% πιθανότητα για το ίδιο τμήμα
            if (rand() % 100 < 80) {
                accountA = rand() % 500 + 1;
            } else {
                accountA = rand() % 500 + 501;
            }
            fprintf(file, "%d %d %d %.2f\n", departmentNumber, queryType, accountA, amount);  // Γράφει το αίτημα στο αρχείο

        } else if (randomPercent < 95) {
            queryType = 3;  // Τύπος αιτήματος 3 (Μεταφορά Χρημάτων)
            accountA = rand() % 500 + 1;  // Τυχαίος λογαριασμός από Department 1
            accountB = rand() % 500 + 1;  // Τυχαίος λογαριασμός για τον λογαριασμό προορισμού
            fprintf(file, "%d %d %d %d %.2f\n", departmentNumber, queryType, accountA, accountB, amount);  // Γράφει το αίτημα

        } else {
            queryType = 4;  // Τύπος αιτήματος 4 (Υπολογισμός Μέσου Υπολοίπου)
            fprintf(file, "%d %d %d\n", departmentNumber, queryType, departmentNumber);  // Γράφει το αίτημα
        }
    }

    fclose(file);  // Κλείσιμο του αρχείου μετά τη δημιουργία
    printf("Workload file '%s' created successfully.\n", filename);  // Εκτύπωση επιβεβαίωσης
}

// Συνάρτηση για τη λήψη και καταγραφή των ολοκληρωμένων αιτημάτων από τον server
void receive_completed_requests(int client_socket, const char* output_filename) {
    FILE *file = fopen(output_filename, "w");  // Άνοιγμα αρχείου για εγγραφή των αποτελεσμάτων
    if (file == NULL) {
        perror("Unable to open output file");  // Έλεγχος αν το αρχείο άνοιξε
        exit(EXIT_FAILURE);  // Έξοδος αν αποτύχει το άνοιγμα
    }

    Request response;  // Δομή που αποθηκεύει την απάντηση από τον server
    while (recv(client_socket, &response, sizeof(Request), 0) > 0) {  // Λήψη δεδομένων από το socket
        // Επεξεργασία του είδους του αιτήματος και καταγραφή στο αρχείο
        if (response.queryType == 1) {
            fprintf(file, "Dept %d: Query Balance - Account %d, Balance: %.2f\n", response.departmentNumber, response.accountNumberA, response.amount);
        } else if (response.queryType == 2) {
            fprintf(file, "Dept %d: Update Balance - Account %d, New Balance: %.2f\n", response.departmentNumber, response.accountNumberA, response.amount);
        } else if (response.queryType == 3) {
            fprintf(file, "Dept %d: Transfer - From Account %d to Account %d, Amount: %.2f\n", response.departmentNumber, response.accountNumberA, response.accountNumberB, response.amount);
        } else if (response.queryType == 4) {
            fprintf(file, "Dept %d: Calculate Average Balance, Average: %.2f\n", response.departmentNumber, response.amount);
        }
    }

    fclose(file);  // Κλείσιμο του αρχείου
    printf("Completed requests received and logged to '%s'\n", output_filename);  // Εκτύπωση επιβεβαίωσης
}

int main() {
    int sock;  // Μεταβλητή για το socket
    struct sockaddr_in server;  // Δομή για τη διεύθυνση του server

    generate_workload_file("dep1_workload.txt");  // Δημιουργία αρχείου workload

    sock = socket(AF_INET, SOCK_STREAM, 0);  // Δημιουργία socket τύπου TCP
    if (sock == -1) {
        printf("Could not create socket");  // Έλεγχος αν το socket δημιουργήθηκε επιτυχώς
    }

    server.sin_addr.s_addr = inet_addr("127.0.0.1");  // Ορισμός της διεύθυνσης IP του server (τοπικός server)
    server.sin_family = AF_INET;  // Ορισμός της οικογένειας διευθύνσεων (IPv4)
    server.sin_port = htons(PORT);  // Μετατροπή του αριθμού θύρας σε σωστή μορφή

    // Σύνδεση με τον server
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Connection failed");  // Εκτύπωση σφάλματος αν αποτύχει η σύνδεση
        return 1;  // Έξοδος με αποτυχία
    }

    printf("Connected to server\n");  // Εκτύπωση επιτυχούς σύνδεσης

    FILE *file = fopen("dep1_workload.txt", "r");  // Άνοιγμα του αρχείου workload για ανάγνωση
    if (file == NULL) {
        perror("Unable to open workload file");  // Έλεγχος αν άνοιξε επιτυχώς
        exit(EXIT_FAILURE);  // Έξοδος αν αποτύχει
    }

    char buffer[BUFFER_SIZE];  // Δημιουργία buffer για την ανάγνωση γραμμών από το αρχείο
    while (fgets(buffer, BUFFER_SIZE, file) != NULL) {  // Ανάγνωση κάθε γραμμής του workload
        send(sock, buffer, strlen(buffer), 0);  // Αποστολή της γραμμής στον server μέσω του socket
    }

    fclose(file);  // Κλείσιμο του αρχείου μετά την αποστολή

    // Λήψη των ολοκληρωμένων αιτημάτων από τον server και καταγραφή τους σε αρχείο
    receive_completed_requests(sock, "completed_requests_dep1.txt");

    close(sock);  // Κλείσιμο του socket μετά την ολοκλήρωση της επικοινωνίας
    return 0;  // Επιτυχής έξοδος
}

