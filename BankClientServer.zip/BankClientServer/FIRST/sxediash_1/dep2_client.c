#include "bank.h"  // Συμπεριλαμβάνει το header file "bank.h" που πιθανότατα περιέχει τις δομές και δηλώσεις που χρησιμοποιούνται στο πρόγραμμα.
#include <sys/socket.h>  // Χρησιμοποιείται για τη δημιουργία και τη διαχείριση των sockets.
#include <arpa/inet.h>  // Περιλαμβάνει συναρτήσεις για διευθύνσεις internet, όπως η `inet_addr`.
#include <unistd.h>  // Παρέχει διάφορες συναρτήσεις, όπως το `close()`.

#define PORT 8080  // Ορίζει την πόρτα στην οποία θα συνδεθεί ο client στον server.
#define WORKLOAD_SIZE 300000  // Ορίζει το μέγεθος του αρχείου workload (300,000 γραμμές).
#define BUFFER_SIZE 1024  // Ορίζει το μέγεθος του buffer που θα χρησιμοποιείται για τη μεταφορά δεδομένων.

void generate_workload_file(const char* filename) {  // Δημιουργεί το workload αρχείο που περιέχει εντολές προς τον server.
    srand(time(0));  // Αρχικοποιεί τον random number generator με την τρέχουσα ώρα.
    FILE *file = fopen(filename, "w");  // Ανοίγει το αρχείο για εγγραφή.

    if (file == NULL) {  // Ελέγχει αν το αρχείο άνοιξε σωστά.
        perror("Unable to open workload file");  // Εμφανίζει μήνυμα λάθους αν δεν μπορεί να ανοίξει το αρχείο.
        exit(EXIT_FAILURE);  // Τερματίζει το πρόγραμμα.
    }

    for (int i = 0; i < WORKLOAD_SIZE; i++) {  // Επαναλαμβάνει 300,000 φορές για να δημιουργήσει το workload.
        int queryType;  // Ορίζει τον τύπο του query.
        int departmentNumber = DEPARTMENT_2;  // Ορίζει το τμήμα ως DEPARTMENT_2 (προφανώς αντιστοιχεί στο τμήμα του πελάτη).
        int accountA, accountB;  // Ορίζει τους αριθμούς των λογαριασμών για τα queries.
        float amount = (float)(rand() % 1000);  // Δημιουργεί ένα τυχαίο ποσό για updates και transfers.

        int randomPercent = rand() % 100;  // Δημιουργεί έναν τυχαίο αριθμό από το 0 ως το 99.

        if (randomPercent < 35) {  // 35% πιθανότητα για "Query Balance".
            queryType = 1;  // Ορίζει το query type ως 1 (Query Balance).
            if (rand() % 100 < 80) {  // 80% πιθανότητα να αφορά το ίδιο τμήμα (Department 2).
                accountA = rand() % 500 + 501;  // Επιλέγει τυχαίο λογαριασμό (501-1000) για Department 2.
            } else {  // 20% πιθανότητα για διαφορετικό τμήμα (Department 1).
                accountA = rand() % 500 + 1;  // Επιλέγει τυχαίο λογαριασμό (1-500) για Department 1.
            }
            fprintf(file, "%d %d %d\n", departmentNumber, queryType, accountA);  // Γράφει το query στο αρχείο.

        } else if (randomPercent < 70) {  // 35% πιθανότητα για "Update Balance".
            queryType = 2;  // Ορίζει το query type ως 2 (Update Balance).
            if (rand() % 100 < 80) {  // 80% πιθανότητα να αφορά το ίδιο τμήμα (Department 2).
                accountA = rand() % 500 + 501;
            } else {  // 20% πιθανότητα για διαφορετικό τμήμα.
                accountA = rand() % 500 + 1;
            }
            fprintf(file, "%d %d %d %.2f\n", departmentNumber, queryType, accountA, amount);  // Γράφει το query στο αρχείο.

        } else if (randomPercent < 95) {  // 25% πιθανότητα για "Transfer Money".
            queryType = 3;  // Ορίζει το query type ως 3 (Transfer Money).
            accountA = rand() % 500 + 501;  // Επιλέγει λογαριασμό από Department 2.
            accountB = rand() % 500 + 501;  // Επιλέγει άλλον λογαριασμό από Department 2.
            fprintf(file, "%d %d %d %d %.2f\n", departmentNumber, queryType, accountA, accountB, amount);  // Γράφει το query στο αρχείο.

        } else {  // 5% πιθανότητα για "Calculate Average Balance".
            queryType = 4;  // Ορίζει το query type ως 4 (Calculate Average Balance).
            fprintf(file, "%d %d %d\n", departmentNumber, queryType, departmentNumber);  // Γράφει το query στο αρχείο.
        }
    }

    fclose(file);  // Κλείνει το αρχείο.
    printf("Workload file '%s' created successfully.\n", filename);  // Εμφανίζει μήνυμα επιτυχίας.
}

void receive_completed_requests(int client_socket, const char* output_filename) {  // Λαμβάνει τις ολοκληρωμένες αιτήσεις από τον server και τις καταγράφει σε αρχείο.
    FILE *file = fopen(output_filename, "w");  // Ανοίγει το αρχείο εξόδου για εγγραφή.
    if (file == NULL) {  // Ελέγχει αν το αρχείο άνοιξε σωστά.
        perror("Unable to open output file");  // Εμφανίζει μήνυμα λάθους αν δεν μπορεί να ανοίξει το αρχείο.
        exit(EXIT_FAILURE);  // Τερματίζει το πρόγραμμα.
    }

    Request response;  // Δημιουργεί μια δομή για να αποθηκεύει τις απαντήσεις του server.
    while (recv(client_socket, &response, sizeof(Request), 0) > 0) {  // Λαμβάνει δεδομένα από τον server.
        if (response.queryType == 1) {  // Αν το query είναι "Query Balance".
            fprintf(file, "Dept %d: Query Balance - Account %d, Balance: %.2f\n", response.departmentNumber, response.accountNumberA, response.amount);
        } else if (response.queryType == 2) {  // Αν το query είναι "Update Balance".
            fprintf(file, "Dept %d: Update Balance - Account %d, New Balance: %.2f\n", response.departmentNumber, response.accountNumberA, response.amount);
        } else if (response.queryType == 3) {  // Αν το query είναι "Transfer Money".
            fprintf(file, "Dept %d: Transfer - From Account %d to Account %d, Amount: %.2f\n", response.departmentNumber, response.accountNumberA, response.accountNumberB, response.amount);
        } else if (response.queryType == 4) {  // Αν το query είναι "Calculate Average Balance".
            fprintf(file, "Dept %d: Calculate Average Balance, Average: %.2f\n", response.departmentNumber, response.amount);
        }
    }

    fclose(file);  // Κλείνει το αρχείο.
    printf("Completed requests received and logged to '%s'\n", output_filename);  // Εμφανίζει μήνυμα επιτυχίας.
}

int main() {
    int sock;  // Δημιουργεί μια μεταβλητή για το socket.
    struct sockaddr_in server;  // Δημιουργεί μια δομή για να αποθηκεύει τη διεύθυνση του server.

    generate_workload_file("dep2_workload.txt");  // Καλεί τη συνάρτηση για να δημιουργήσει το workload αρχείο.

    sock = socket(AF_INET, SOCK_STREAM, 0);  // Δημιουργεί το socket.
    if (sock == -1) {  // Ελέγχει αν το socket δημιουργήθηκε σωστά.
        printf("Could not create socket");
    }

    server.sin_addr.s_addr = inet_addr("127.0.0.1");  // Ορίζει τη διεύθυνση του server (localhost).
    server.sin_family = AF_INET;  // Ορίζει την οικογένεια διευθύνσεων (IPv4).
    server.sin_port = htons(PORT);  // Ορίζει την πόρτα του server.

    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {  // Προσπαθεί να συνδεθεί με τον server.
        perror("Connection failed");  // Εμφανίζει μήνυμα λάθους αν η σύνδεση αποτύχει.
        return 1;  // Τερματίζει το πρόγραμμα με κωδικό λάθους.
    }

    printf("Connected to server\n");  // Εμφανίζει μήνυμα ότι η σύνδεση ήταν επιτυχής.

    FILE *file = fopen("dep2_workload.txt", "r");  // Ανοίγει το workload αρχείο για ανάγνωση.
    if (file == NULL) {  // Ελέγχει αν το αρχείο άνοιξε σωστά.
        perror("Unable to open workload file");  // Εμφανίζει μήνυμα λάθους αν δεν μπορεί να ανοίξει το αρχείο.
        exit(EXIT_FAILURE);  // Τερματίζει το πρόγραμμα.
    }

    char buffer[BUFFER_SIZE];  // Δημιουργεί ένα buffer για την αποστολή των δεδομένων.
    while (fgets(buffer, BUFFER_SIZE, file) != NULL) {  // Διαβάζει κάθε γραμμή του workload αρχείου.
        send(sock, buffer, strlen(buffer), 0);  // Στέλνει την τρέχουσα γραμμή στον server.
    }

    fclose(file);  // Κλείνει το αρχείο workload.

    // Λαμβάνει τις ολοκληρωμένες αιτήσεις από τον server και τις καταγράφει σε αρχείο.
    receive_completed_requests(sock, "completed_requests_dep2.txt");

    close(sock);  // Κλείνει το socket.
    return 0;  // Τερματίζει το πρόγραμμα επιτυχώς.
}

