#ifndef BANK_SYSTEM_H
#define BANK_SYSTEM_H

#include <stdio.h>
#include <stdlib.h>

// Shared function prototypes
void process_query(int query_type, int department);
void forward_to_central_server(int query_type, int department);
void process_forwarded_query(int query_type, int department);

#endif

