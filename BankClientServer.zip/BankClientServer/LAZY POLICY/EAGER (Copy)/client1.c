#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>

#define TOTAL_QUERIES 300000
#define QUERY_TYPE_1_PERCENT 0.35
#define QUERY_TYPE_2_PERCENT 0.35
#define QUERY_TYPE_3_PERCENT 0.25
#define QUERY_TYPE_4_PERCENT 0.05
#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8080
#define BUFFER_SIZE 1024

#define DEPARTMENT_PROBABILITY 0.8  // 80% chance for Query Type 1 and 2 to use Department 1 accounts

// Function to generate a random account number from Department 1 (1–500) or Department 2 (501–1000)
int get_random_account_from_department(int department) {
    if (department == 1) {
        return rand() % 500 + 1;  // Department 1: accounts 1-500
    } else {
        return rand() % 500 + 501;  // Department 2: accounts 501-1000
    }
}

// Function to generate a random account number without any department restriction
int get_random_account_any_department() {
    return rand() % 1000 + 1;  // Account numbers 1-1000, from either department
}

// Function to receive and print the server's response (only if successful)
void receive_response(int sock) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';  // Null-terminate the received string
        printf("Server response: %s", buffer);  // Print the server's response
    } else {
        printf("Failed to receive response from server.\n");
    }
}

// Function to write the generated query to the workload file
void log_query(FILE* workload_file, const char* query) {
    fprintf(workload_file, "%s", query);  // Write the query to the file
}

// Function to generate the query details and send them to Server 1
void generate_query(int sock, int query_type, FILE* workload_file) {
    char buffer[256];
    int accountNumberA;
    int accountNumberB;
    float amount;

    // Query Types 1 and 2: 80% chance to involve Department 1 accounts, 20% for Department 2 accounts
    if (query_type == 1 || query_type == 2) {
        if ((float)rand() / RAND_MAX < DEPARTMENT_PROBABILITY) {
            accountNumberA = get_random_account_from_department(1);  // 80% probability for Department 1
        } else {
            accountNumberA = get_random_account_from_department(2);  // 20% probability for Department 2
        }
    } else {
        accountNumberA = get_random_account_from_department(1);  // For Query Type 4, only Department 1
    }

    switch (query_type) {
        case 1:  // Check balance of accountNumberA
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d, Account: %d\n", query_type, accountNumberA);
            break;

        case 2:  // Add/Remove money from accountNumberA
            amount = (rand() % 2001) - 1000;  // Random amount between -1000 and +1000
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d, Account: %d, Amount: %.2f\n", query_type, accountNumberA, amount);
            break;

        case 3:  // Transfer money from accountNumberA to accountNumberB (no department restrictions)
            accountNumberA = get_random_account_any_department();  // Any account from any department
            accountNumberB = get_random_account_any_department();  // Any account from any department
            while (accountNumberB == accountNumberA) {
                accountNumberB = get_random_account_any_department();  // Ensure account numbers are different
            }
            amount = (rand() % 1000) + 1;  // Random amount between 1 and 1000
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d, Account A: %d, Account B: %d, Amount: %.2f\n", query_type, accountNumberA, accountNumberB, amount);
            break;

        case 4:  // Display average balance of department (must always be in Department 1)
            snprintf(buffer, sizeof(buffer), "Department: 1, Query Type: %d\n", query_type);
            break;
    }

    // Log the query to the workload file
    log_query(workload_file, buffer);

    // Send the generated query to the server
    send(sock, buffer, strlen(buffer), 0);

    // Receive the server's response
    receive_response(sock);
}

// Function to generate the workload for Department 1 and send it to Server 1
void generate_workload(int department) {
    srand(time(NULL));  // Seed the random number generator

    // Create socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation error");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);

    // Convert IPv4 address from text to binary
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        perror("Invalid address/Address not supported");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Open the workload file for writing
    FILE* workload_file = fopen("workload1.txt", "w");
    if (workload_file == NULL) {
        perror("Failed to open workload file");
        close(sock);
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < TOTAL_QUERIES; ++i) {
        float rand_value = (float)rand() / RAND_MAX;  // Generate a random float between 0 and 1
        int query_type;

        // Assign query type based on probabilities
        if (rand_value < QUERY_TYPE_1_PERCENT) {
            query_type = 1;  // Query Type 1 (35%)
        } else if (rand_value < QUERY_TYPE_1_PERCENT + QUERY_TYPE_2_PERCENT) {
            query_type = 2;  // Query Type 2 (35%)
        } else if (rand_value < QUERY_TYPE_1_PERCENT + QUERY_TYPE_2_PERCENT + QUERY_TYPE_3_PERCENT) {
            query_type = 3;  // Query Type 3 (25%)
        } else {
            query_type = 4;  // Query Type 4 (5%)
        }

        // Generate the query and send it to the server
        generate_query(sock, query_type, workload_file);
    }

    // Close the workload file after all queries are logged
    fclose(workload_file);

    close(sock);
    printf("Workload for Department %d sent to Server 1 and saved to 'workload1.txt'.\n", department);
}

int main() {
    // Client 1 generates workload for Department 1 and sends it to Server 1
    generate_workload(1);
    return 0;
}

