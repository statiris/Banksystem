#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CENTRAL_ACCOUNT_FILE "accounts.txt"
#define DEP1_ACCOUNT_FILE "dep1_accounts.txt"
#define DEP2_ACCOUNT_FILE "dep2_accounts.txt"
#define MAX_ACCOUNTS 1000

// Function to generate a random balance between 100 and 10000
float generate_random_balance() {
    return (float)(rand() % 10000 + 100);  // Random number between 100 and 10000
}

// Function to initialize the central account file with random balances
void initialize_central_accounts() {
    FILE *central_file = fopen(CENTRAL_ACCOUNT_FILE, "w");
    if (!central_file) {
        perror("Failed to open central account file for writing");
        exit(EXIT_FAILURE);
    }

    srand(time(NULL));  // Seed the random number generator

    // Create 1000 accounts with random balances
    for (int account_number = 1; account_number <= MAX_ACCOUNTS; account_number++) {
        float balance = generate_random_balance();
        int department = (account_number <= 500) ? 1 : 2;  // Department 1 for accounts 1-500, Department 2 for 501-1000
        fprintf(central_file, "%d,%d,%.2f\n", account_number, department, balance);
    }

    fclose(central_file);
}

// Function to initialize local account files from the central account file
void initialize_local_accounts() {
    FILE *central_file = fopen(CENTRAL_ACCOUNT_FILE, "r");
    if (!central_file) {
        perror("Failed to open central account file");
        exit(EXIT_FAILURE);
    }

    FILE *dep1_file = fopen(DEP1_ACCOUNT_FILE, "w");
    FILE *dep2_file = fopen(DEP2_ACCOUNT_FILE, "w");
    if (!dep1_file || !dep2_file) {
        perror("Failed to open local account files for writing");
        exit(EXIT_FAILURE);
    }

    int account_number, department;
    float balance;
    char buffer[256];

    // Distribute accounts to dep1 and dep2 files based on department
    while (fgets(buffer, sizeof(buffer), central_file)) {
        sscanf(buffer, "%d,%d,%f", &account_number, &department, &balance);
        if (department == 1) {
            fprintf(dep1_file, "%d,%.2f\n", account_number, balance);  // Write to dep1_accounts.txt
        } else {
            fprintf(dep2_file, "%d,%.2f\n", account_number, balance);  // Write to dep2_accounts.txt
        }
    }

    fclose(central_file);
    fclose(dep1_file);
    fclose(dep2_file);
}

int main() {
    // Initialize the central accounts file with random balances
    initialize_central_accounts();

    // Initialize the local account files from the central accounts
    initialize_local_accounts();

    printf("Central and local account files have been initialized with random balances.\n");

    return 0;
}

