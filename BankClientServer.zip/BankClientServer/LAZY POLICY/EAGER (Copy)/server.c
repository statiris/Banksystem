#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define CENTRAL_PORT 8081
#define BUFFER_SIZE 1024
#define MAX_ACCOUNTS 1000  // To handle all department accounts

// Structure to store account data
typedef struct {
    int accountNumber;
    int departmentNumber;  // To distinguish accounts by department
    float balance;
    int modified;  // New flag for lazy update
} Account;

Account accounts[MAX_ACCOUNTS];
int num_accounts = 0;

// Function to load accounts from a file
void load_accounts(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open account file");
        exit(EXIT_FAILURE);
    }

    while (fscanf(file, "%d,%d,%f", &accounts[num_accounts].accountNumber, 
                  &accounts[num_accounts].departmentNumber, &accounts[num_accounts].balance) == 3) {
        accounts[num_accounts].modified = 0;  // Initialize the modified flag
        num_accounts++;
        if (num_accounts >= MAX_ACCOUNTS) break;  // Prevent overloading the array
    }

    fclose(file);
    printf("Loaded %d accounts from '%s'.\n", num_accounts, filename);
}

// Function to save updated account balances to the file
void save_accounts(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Failed to open account file for writing");
        return;
    }

    for (int i = 0; i < num_accounts; i++) {
        fprintf(file, "%d,%d,%.2f\n", accounts[i].accountNumber, accounts[i].departmentNumber, accounts[i].balance);
    }

    fclose(file);
}

// Function to synchronize modified accounts with the department server
void synchronize_with_department(Account *account) {
    if (account->modified) {
        // Create a query to update the department server with the modified account
        char query[BUFFER_SIZE];
        snprintf(query, sizeof(query), "Update Account: %d, Balance: %.2f\n", account->accountNumber, account->balance);
        

        
        // Reset the modified flag after synchronization
        account->modified = 0;
    }
}

// Function to find an account by department and account number
Account* find_account(int departmentNumber, int accountNumber) {
    for (int i = 0; i < num_accounts; i++) {
        if (accounts[i].accountNumber == accountNumber && accounts[i].departmentNumber == departmentNumber) {
            // Synchronize with the department server if the account is modified
            synchronize_with_department(&accounts[i]);
            return &accounts[i];
        }
    }
    return NULL;  // Account not found
}

// Function to process a forwarded query
void process_query(int client_sock, char *query) {
    int department, query_type, accountA, accountB;
    float amount;
    char response[BUFFER_SIZE];

    // Parsing the query
    if (sscanf(query, "Department: %d, Query Type: %d, Account: %d", &department, &query_type, &accountA) < 2) {
        snprintf(response, sizeof(response), "Invalid query format: %s\n", query);
        send(client_sock, response, strlen(response), 0);
        return;
    }

    Account *accA, *accB;

    switch (query_type) {
        case 1:  // Query Type 1: Check balance of an account
            accA = find_account(department, accountA);
            if (accA) {
                snprintf(response, sizeof(response), "Account %d (Dept %d) balance: %.2f\n", accA->accountNumber, accA->departmentNumber, accA->balance);
            } else {
                snprintf(response, sizeof(response), "Account %d not found in Central Server\n", accountA);
            }
            send(client_sock, response, strlen(response), 0);
            break;

        case 2:  // Query Type 2: Add/Remove money from an account
            if (sscanf(query, "Department: %d, Query Type: %d, Account: %d, Amount: %f", &department, &query_type, &accountA, &amount) == 4) {
                accA = find_account(department, accountA);
                if (accA) {
                    accA->balance += amount;  // Add/Remove the amount
                    accA->modified = 1;  // Mark the account as modified for lazy update
                    snprintf(response, sizeof(response), "Account %d updated. New balance: %.2f\n", accA->accountNumber, accA->balance);
                    save_accounts("accounts.txt");  // Save the updated balances to the file
                } else {
                    snprintf(response, sizeof(response), "Account %d not found in Central Server\n", accountA);
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for add/remove money: %s\n", query);
            }
            send(client_sock, response, strlen(response), 0);
            break;

        case 3:  // Query Type 3: Transfer money between accounts
            if (sscanf(query, "Department: %d, Query Type: %d, Account A: %d, Account B: %d, Amount: %f", &department, &query_type, &accountA, &accountB, &amount) == 5) {
                accA = find_account(department, accountA);
                accB = find_account(department, accountB);
                if (accA && accB) {
                    if (accA->balance >= amount) {
                        accA->balance -= amount;
                        accB->balance += amount;
                        accA->modified = 1;  // Mark Account A as modified
                        accB->modified = 1;  // Mark Account B as modified
                        snprintf(response, sizeof(response), "Transferred %.2f from Account %d to Account %d\n", amount, accA->accountNumber, accB->accountNumber);
                        save_accounts("accounts.txt");  // Save the updated balances to the file
                    } else {
                        snprintf(response, sizeof(response), "Insufficient funds in Account %d\n", accA->accountNumber);
                    }
                } else {
                    snprintf(response, sizeof(response), "One or both accounts not found in Central Server\n");
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for transfer: %s\n", query);
            }
            send(client_sock, response, strlen(response), 0);
            break;

        default:
            snprintf(response, sizeof(response), "Unknown query type: %d\n", query_type);
            send(client_sock, response, strlen(response), 0);
            break;
    }
}

// Function for handling incoming connections from local servers
void *handle_client(void *socket_desc) {
    int client_sock = *(int *)socket_desc;
    free(socket_desc);
    char buffer[BUFFER_SIZE];
    ssize_t read_size;

    // Continuously receive and process queries from the local server
    while ((read_size = recv(client_sock, buffer, BUFFER_SIZE, 0)) > 0) {
        buffer[read_size] = '\0';  // Null-terminate the received data
        process_query(client_sock, buffer);  // Process the query and send the result back
    }

    if (read_size == 0) {
        //printf("Local server disconnected.\n");
    } else if (read_size == -1) {
        perror("recv failed");
    }

    close(client_sock);
    return NULL;
}

int main() {
    int server_sock, client_sock, *new_sock;
    struct sockaddr_in server, client;
    socklen_t client_len = sizeof(client);

    // Load accounts from the file (e.g., accounts.txt)
    load_accounts("accounts.txt");  // This reads the account balances for all departments

    // Create socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        perror("Could not create socket");
        exit(EXIT_FAILURE);
    }
    printf("Central server socket created.\n");

    // Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(CENTRAL_PORT);

    // Bind
    if (bind(server_sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    printf("Central server bind done.\n");

    // Listen
    listen(server_sock, 3);
    printf("Central server waiting for incoming connections...\n");

    // Accept incoming connections
    while ((client_sock = accept(server_sock, (struct sockaddr *)&client, &client_len))) {

        // Create a new thread for each local server connection
        pthread_t client_thread;
        new_sock = malloc(1);
        *new_sock = client_sock;

        if (pthread_create(&client_thread, NULL, handle_client, (void *)new_sock) < 0) {
            perror("Could not create thread");
            close(client_sock);
            continue;
        }
    }

    if (client_sock < 0) {
        perror("Accept failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    close(server_sock);
    return 0;
}

