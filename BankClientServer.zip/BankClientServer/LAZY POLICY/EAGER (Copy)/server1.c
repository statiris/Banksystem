#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>

#define LOCAL_PORT 8080
#define CENTRAL_SERVER_IP "127.0.0.1"
#define CENTRAL_SERVER_PORT 8081
#define BUFFER_SIZE 1024
#define MAX_ACCOUNTS 500

// Structure to store account data
typedef struct {
    int accountNumber;
    float balance;
    int modified;  // New flag to indicate if the account is locally modified
} Account;

Account accounts[MAX_ACCOUNTS];
int num_accounts = 0;

void forward_to_central_server(char *query, int client_sock); 

// Function to load accounts from file
void load_accounts(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open account file");
        exit(EXIT_FAILURE);
    }

    while (fscanf(file, "%d,%f", &accounts[num_accounts].accountNumber, &accounts[num_accounts].balance) == 2) {
        accounts[num_accounts].modified = 0;  // Initialize modified flag

        num_accounts++;
        if (num_accounts >= MAX_ACCOUNTS) break; // Prevent overloading the array
    }

    fclose(file);
    printf("Loaded %d accounts from '%s'.\n", num_accounts, filename);
}

// Function to save the updated account balances to the file
void save_accounts(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Failed to open account file for writing");
        return;
    }

    for (int i = 0; i < num_accounts; i++) {
        fprintf(file, "%d,%.2f\n", accounts[i].accountNumber, accounts[i].balance);
    }

    fclose(file);
}

// Function to synchronize local changes with the central server (Lazy Update)
void synchronize_with_central_server(Account *account) {
    if (account->modified) {
        char query[BUFFER_SIZE];
        snprintf(query, sizeof(query), "Update Account: %d, Balance: %.2f\n", account->accountNumber, account->balance);
        
        // Placeholder function to forward the query to the central server
        forward_to_central_server(query, -1);  // -1 indicates no specific client is waiting for this response
        
        // After synchronization, reset the modified flag
        account->modified = 0;
    }
}

// Function to find an account by account number
Account* find_account(int accountNumber) {
    for (int i = 0; i < num_accounts; i++) {
        if (accounts[i].accountNumber == accountNumber) {
            // Before returning the account, synchronize if modified
            synchronize_with_central_server(&accounts[i]);
            return &accounts[i];
        }
    }
    return NULL; // Account not found
}


// Function to forward a request to the central server
void forward_to_central_server(char *query, int client_sock) {
    int central_sock;
    struct sockaddr_in central_server_addr;

    // Create socket to connect to central server
    central_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (central_sock < 0) {
        perror("Socket creation error");
        exit(EXIT_FAILURE);
    }

    // Set up the central server's address
    central_server_addr.sin_family = AF_INET;
    central_server_addr.sin_port = htons(CENTRAL_SERVER_PORT);

    // Convert IP address
    if (inet_pton(AF_INET, CENTRAL_SERVER_IP, &central_server_addr.sin_addr) <= 0) {
        perror("Invalid address/Address not supported");
        close(central_sock);
        exit(EXIT_FAILURE);
    }

    // Connect to the central server
    if (connect(central_sock, (struct sockaddr *)&central_server_addr, sizeof(central_server_addr)) < 0) {
        perror("Connection to central server failed");
        close(central_sock);
        exit(EXIT_FAILURE);
    }

    // Send the query to the central server
    send(central_sock, query, strlen(query), 0);

    // Receive response from central server
    char buffer[BUFFER_SIZE];
    ssize_t bytes_received = recv(central_sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        send(client_sock, buffer, strlen(buffer), 0);  // Forward the response to the client
    }

    // Close the connection to the central server
    close(central_sock);
}


// Function to process a query and send the result back to the client
void process_query(int client_sock, char *query) {
    int department, query_type, accountA, accountB;
    float amount;
    char response[BUFFER_SIZE];

    // Parsing the query
    if (sscanf(query, "Department: %d, Query Type: %d, Account: %d", &department, &query_type, &accountA) < 2) {
        snprintf(response, sizeof(response), "Invalid query format: %s\n", query);
        send(client_sock, response, strlen(response), 0);
        return;
    }

    Account *accA, *accB;

    // Check if the account belongs to Department 1 (local accounts)
    accA = find_account(accountA);
    if (accA == NULL && department == 1) {  // If account doesn't belong to Department 1, forward to Central Server
        forward_to_central_server(query, client_sock);
        return;
    }

    // Process local queries for Department 1
    switch (query_type) {
        case 1:  // Query Type 1: Check balance of account
            if (accA) {
                snprintf(response, sizeof(response), "Account %d balance: %.2f\n", accA->accountNumber, accA->balance);
            } else {
                //snprintf(response, sizeof(response), "Account %d not found in Department 1\n", accountA);
            }
            send(client_sock, response, strlen(response), 0);
            break;

        case 2:  // Query Type 2: Add/Remove money from account
            if (sscanf(query, "Department: %d, Query Type: %d, Account: %d, Amount: %f", &department, &query_type, &accountA, &amount) == 4) {
                if (accA) {
                    accA->balance += amount;  // Add/Remove the amount
                    accA->modified = 1;  // Mark the account as modified for lazy update
                    snprintf(response, sizeof(response), "Account %d updated. New balance: %.2f\n", accA->accountNumber, accA->balance);
                    save_accounts("dep1_accounts.txt");  // Save the updated balances to the file
                } else {
                   // snprintf(response, sizeof(response), "Account %d not found in Department 1\n", accountA);
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for add/remove money: %s\n", query);
            }
            send(client_sock, response, strlen(response), 0);
            break;

        case 3:  // Query Type 3: Transfer money from account A to account B (local transfers)
            if (sscanf(query, "Department: %d, Query Type: %d, Account A: %d, Account B: %d, Amount: %f", &department, &query_type, &accountA, &accountB, &amount) == 5) {
                accA = find_account(accountA);
                accB = find_account(accountB);
                if (accA && accB) {
                    if (accA->balance >= amount) {
                        accA->balance -= amount;
                        accB->balance += amount;
                        accA->modified = 1;  // Mark as modified
                        accB->modified = 1;  // Mark as modified
                        snprintf(response, sizeof(response), "Transferred %.2f from Account %d to Account %d\n", amount, accA->accountNumber, accB->accountNumber);
                        save_accounts("dep1_accounts.txt");  // Save the updated balances to the file
                    } else {
                        snprintf(response, sizeof(response), "Insufficient funds in Account %d\n", accA->accountNumber);
                    }
                } else {
                   // snprintf(response, sizeof(response), "One or both accounts not found in Department 1\n");
                }
            } else {
                snprintf(response, sizeof(response), "Invalid query format for transfer: %s\n", query);
            }
            send(client_sock, response, strlen(response), 0);
            break;

        case 4:  // Query Type 4: Display average balance of department with timestamp
            {
                float total_balance = 0;
                for (int i = 0; i < num_accounts; i++) {
                    total_balance += accounts[i].balance;
                }
                float average_balance = total_balance / num_accounts;

                // Get the current timestamp
                time_t now = time(NULL);
                char timestamp[64];  // Make timestamp buffer smaller
                strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", localtime(&now));

                // Ensure no truncation by formatting the response in two steps
                int len = snprintf(response, sizeof(response), "Average balance for Department 1: %.2f\n", average_balance);
                snprintf(response + len, sizeof(response) - len, "Timestamp: %s\n", timestamp);

                send(client_sock, response, strlen(response), 0);
            }
            break;

        default:
            //snprintf(response, sizeof(response), "Unknown query type: %d\n", query_type);
            send(client_sock, response, strlen(response), 0);
            break;
    }
}

// Function for handling incoming connections from clients
void *handle_client(void *socket_desc) {
    int client_sock = *(int *)socket_desc;
    free(socket_desc);
    char buffer[BUFFER_SIZE];
    ssize_t read_size;

    // Continuously receive and process queries from the client
    while ((read_size = recv(client_sock, buffer, BUFFER_SIZE, 0)) > 0) {
        buffer[read_size] = '\0';  // Null-terminate the received data
        process_query(client_sock, buffer);  // Process the query and send the result back
    }

    if (read_size == 0) {
        printf("Client disconnected.\n");
    } else if (read_size == -1) {
        perror("recv failed");
    }

    close(client_sock);
    return NULL;
}

int main() {
    int server_sock, client_sock, *new_sock;
    struct sockaddr_in server, client;
    socklen_t client_len = sizeof(client);

    // Load accounts from the file
    load_accounts("dep1_accounts.txt");  // This reads the initial account balances

    // Create socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        perror("Could not create socket");
        exit(EXIT_FAILURE);
    }
    printf("Department 1 server socket created.\n");

    // Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(LOCAL_PORT);

    // Bind
    if (bind(server_sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Department 1 server bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    printf("Department 1 server bind done.\n");

    // Listen
    listen(server_sock, 3);
    printf("Department 1 server waiting for incoming connections...\n");

    // Accept incoming connections
    while ((client_sock = accept(server_sock, (struct sockaddr *)&client, &client_len))) {
        printf("Connection accepted.\n");

        // Create a new thread for each client
        pthread_t client_thread;
        new_sock = malloc(1);
        *new_sock = client_sock;

        if (pthread_create(&client_thread, NULL, handle_client, (void *)new_sock) < 0) {
            perror("Could not create thread");
            close(client_sock);
            continue;
        }

        printf("Handler assigned.\n");
    }

    if (client_sock < 0) {
        perror("Accept failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    close(server_sock);
    return 0;
}

